# CartCompare - Smart E-commerce Cart Switcher

A powerful browser extension that compares cart values across multiple e-commerce platforms and helps users switch to cheaper options automatically.

## Features

### 🛒 **Cart Extraction & Matching**
- Automatically detects and extracts cart items from supported e-commerce sites
- Identifies equivalent products across different platforms using AI-powered matching
- Considers product titles, specifications, images, and user preferences

### 💰 **Smart Price Comparison**
- Calculates total cost including item price, shipping, taxes, and discounts
- Presents comprehensive comparison showing potential savings and trade-offs
- Considers delivery time, brand substitutions, and seller ratings

### ⚡ **One-Click Cart Switching**
- "Add All to Cart" functionality with single button click
- Generates pre-filled cart URLs when supported by platforms
- Automated cart building using browser automation for unsupported platforms
- Handles login prompts and user interactions gracefully

### 🛡️ **Robust Error Handling**
- Multiple fallback strategies when automation fails
- Manual cart copying with product links as backup
- Clear error messages and recovery instructions
- Graceful degradation for unsupported scenarios

### 🎨 **Intuitive User Experience**
- Clean, modern UI with loading animations
- Real-time progress tracking for cart building
- Confirmation messages with savings details
- Settings panel for customizing preferences

### 🔒 **Security & Compliance**
- No storage of user credentials
- Respects platform terms of service
- Client-side processing with session awareness
- GDPR, CCPA, and COPPA compliance features

## Supported Platforms

### Primary Platforms
- **Zepto** - 10-15 min delivery
- **Blinkit** - 10-15 min delivery  
- **BigBasket** - 1-2 hours delivery
- **Grofers** - 30-45 min delivery

### Source Platforms
- Amazon.in
- Flipkart
- Other supported e-commerce sites

## Installation

### From Source
1. Clone this repository
2. Open Chrome/Edge and navigate to `chrome://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked" and select the extension directory
5. The extension will be installed and ready to use

### From Chrome Web Store
*Coming soon - extension will be published to Chrome Web Store*

## Usage

### Basic Usage
1. Navigate to any supported e-commerce site
2. Add items to your cart
3. Click the CartCompare extension icon
4. View price comparisons across platforms
5. Click "Add All to Cart" on your preferred platform

### Advanced Features
- **Settings**: Customize brand loyalty, delivery speed priority, and price weight
- **Manual Override**: Review and modify matched products before adding to cart
- **Cart Copy**: Copy cart data to clipboard for manual processing
- **Error Recovery**: Follow guided instructions when automation fails

## Architecture

### Core Modules

#### `CartExtractor` (`js/cartExtractor.js`)
- DOM parsing and cart item extraction
- Platform-specific selectors and parsing logic
- Real-time cart change detection

#### `ProductMatcher` (`js/productMatcher.js`)
- AI-powered product matching across platforms
- Levenshtein distance for title similarity
- Price and image similarity calculations
- User preference weighting

#### `CartAutomation` (`js/cartAutomation.js`)
- Automated cart building and URL generation
- Browser automation for unsupported platforms
- Fallback mechanisms and error handling

#### `SecurityManager` (`js/security.js`)
- Data sanitization and encryption
- Rate limiting and abuse prevention
- Compliance checking (GDPR, CCPA, COPPA)
- XSS protection and input validation

#### `ErrorHandler` (`js/errorHandler.js`)
- Centralized error handling and classification
- Fallback strategy execution
- Error logging and debugging support

### File Structure
```
cart-compare-extension/
├── manifest.json              # Extension manifest
├── popup.html                 # Popup UI
├── popup.css                  # Popup styles
├── popup.js                   # Popup controller
├── content.js                 # Content script
├── content.css                # Content script styles
├── background.js              # Background service worker
├── js/
│   ├── cartExtractor.js       # Cart extraction logic
│   ├── productMatcher.js      # Product matching algorithm
│   ├── cartAutomation.js      # Cart automation
│   ├── security.js            # Security and compliance
│   └── errorHandler.js        # Error handling
├── icons/                     # Extension icons
└── README.md                  # This file
```

## Configuration

### User Preferences
- **Brand Loyalty** (0-100%): How much to prioritize brand consistency
- **Delivery Speed** (0-100%): Priority for faster delivery
- **Seller Rating** (0-100%): Importance of seller ratings
- **Price Weight** (0-100%): Emphasis on price savings

### Platform Settings
- Enable/disable specific platforms
- Custom delivery time preferences
- Brand substitution rules
- Minimum confidence thresholds

## Security Considerations

### Data Protection
- No sensitive data storage
- Client-side processing only
- Encrypted data transmission
- Automatic data sanitization

### Privacy Compliance
- GDPR compliance for EU users
- CCPA compliance for California users
- COPPA compliance for under-13 users
- Transparent data usage policies

### Platform Compliance
- Respects platform Terms of Service
- Rate limiting to prevent abuse
- Graceful handling of anti-bot measures
- User-agent rotation and request throttling

## Development

### Prerequisites
- Node.js 16+ (for development tools)
- Chrome/Edge browser
- Git

### Setup
```bash
git clone <repository-url>
cd cart-compare-extension
npm install  # If package.json exists
```

### Building
```bash
# No build process required - pure JavaScript extension
# Just load the directory in Chrome extensions
```

### Testing
1. Load extension in developer mode
2. Navigate to supported e-commerce sites
3. Test cart extraction and comparison
4. Verify automation and fallback mechanisms

## Troubleshooting

### Common Issues

#### Cart Not Detected
- Ensure you're on a supported platform
- Check if items are actually in the cart
- Try refreshing the page and extension

#### Automation Fails
- Check if platform requires login
- Verify product availability
- Use manual cart copy as fallback

#### No Matches Found
- Adjust matching confidence thresholds
- Check product title similarity
- Try different search terms

### Debug Mode
Enable debug logging by setting `localStorage.debug = 'true'` in browser console.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Code Style
- Use ES6+ features
- Follow existing naming conventions
- Add comments for complex logic
- Ensure error handling is comprehensive

## License

MIT License - see LICENSE file for details

## Support

- **Issues**: Report bugs and feature requests on GitHub
- **Documentation**: Check this README and inline code comments
- **Community**: Join our Discord server (coming soon)

## Roadmap

### Version 1.1
- [ ] Additional platform support
- [ ] Advanced product matching algorithms
- [ ] Bulk cart operations
- [ ] Price history tracking

### Version 1.2
- [ ] Mobile app companion
- [ ] API for third-party integrations
- [ ] Advanced analytics dashboard
- [ ] Machine learning improvements

### Version 2.0
- [ ] Cross-browser support (Firefox, Safari)
- [ ] Desktop application
- [ ] Enterprise features
- [ ] White-label solutions

## Acknowledgments

- Product matching algorithms inspired by e-commerce research
- Security practices based on OWASP guidelines
- UI/UX design following Material Design principles
- Error handling patterns from industry best practices

---

**Note**: This extension is for educational and personal use. Always respect platform terms of service and use responsibly.
