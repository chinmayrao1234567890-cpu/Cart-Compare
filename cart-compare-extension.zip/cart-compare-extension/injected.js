/**
 * Injected Script - Runs in page context
 * Handles direct DOM manipulation and page interactions
 */

(function() {
  'use strict';
  
  // Prevent multiple injections
  if (window.cartCompareInjected) {
    return;
  }
  window.cartCompareInjected = true;

  /**
   * Injected Cart Extractor
   * Direct access to page DOM for cart extraction
   */
  class InjectedCartExtractor {
    constructor() {
      this.platforms = {
        'amazon.in': {
          cartSelectors: {
            items: '[data-item-id]',
            title: '[data-item-id] h3 a, [data-item-id] .a-size-medium',
            price: '.a-price-whole, .a-offscreen',
            quantity: '[data-item-id] .a-dropdown-prompt, [data-item-id] .a-spacing-small select',
            image: '[data-item-id] img',
            removeButton: '[data-item-id] .a-button-delete'
          }
        },
        'flipkart.com': {
          cartSelectors: {
            items: '.IIdQZO ._1AtVbE',
            title: '._2Kn22P',
            price: '._30jeq3',
            quantity: '._3dY_ZR select',
            image: '._396cs4',
            removeButton: '._3dsJAO'
          }
        },
        'zepto.com': {
          cartSelectors: {
            items: '.cart-item',
            title: '.product-title',
            price: '.price',
            quantity: '.quantity-selector select',
            image: '.product-image img',
            removeButton: '.remove-item'
          }
        },
        'blinkit.com': {
          cartSelectors: {
            items: '.cart-item',
            title: '.product-name',
            price: '.price',
            quantity: '.qty-selector select',
            image: '.product-img img',
            removeButton: '.remove-btn'
          }
        },
        'bigbasket.com': {
          cartSelectors: {
            items: '.item',
            title: '.item-name',
            price: '.price',
            quantity: '.qty-selector select',
            image: '.item-img img',
            removeButton: '.remove-item'
          }
        }
      };
    }

    /**
     * Extract cart items from current page
     */
    extractCartItems() {
      const currentDomain = window.location.hostname;
      const platform = this.identifyPlatform(currentDomain);
      
      if (!platform) {
        throw new Error('Unsupported platform');
      }

      const selectors = this.platforms[platform].cartSelectors;
      const items = [];

      const itemElements = document.querySelectorAll(selectors.items);
      
      for (const itemElement of itemElements) {
        try {
          const item = this.extractItemData(itemElement, selectors);
          if (item && item.title && item.price) {
            items.push(item);
          }
        } catch (error) {
          console.warn('Failed to extract item:', error);
        }
      }

      return this.normalizeCartData(items);
    }

    /**
     * Identify platform from domain
     */
    identifyPlatform(domain) {
      for (const platform in this.platforms) {
        if (domain.includes(platform)) {
          return platform;
        }
      }
      return null;
    }

    /**
     * Extract data from cart item element
     */
    extractItemData(itemElement, selectors) {
      const titleElement = itemElement.querySelector(selectors.title);
      const priceElement = itemElement.querySelector(selectors.price);
      const quantityElement = itemElement.querySelector(selectors.quantity);
      const imageElement = itemElement.querySelector(selectors.image);

      const title = titleElement ? titleElement.textContent.trim() : '';
      const price = this.extractPrice(priceElement ? priceElement.textContent : '');
      const quantity = quantityElement ? parseInt(quantityElement.value || quantityElement.textContent) : 1;
      const imageUrl = imageElement ? imageElement.src || imageElement.getAttribute('data-src') : '';
      const productUrl = titleElement ? titleElement.href : '';

      return {
        title,
        price,
        quantity,
        imageUrl,
        productUrl,
        originalElement: itemElement
      };
    }

    /**
     * Extract numeric price from text
     */
    extractPrice(priceText) {
      if (!priceText) return 0;
      
      const numericPrice = priceText.replace(/[^\d.,]/g, '');
      const price = parseFloat(numericPrice.replace(',', ''));
      
      return isNaN(price) ? 0 : price;
    }

    /**
     * Normalize cart data
     */
    normalizeCartData(cartData) {
      return cartData.map(item => ({
        ...item,
        id: this.generateItemId(item),
        normalizedTitle: this.normalizeTitle(item.title),
        totalPrice: item.price * item.quantity
      }));
    }

    /**
     * Generate item ID
     */
    generateItemId(item) {
      return btoa(item.title + item.price).replace(/[^a-zA-Z0-9]/g, '');
    }

    /**
     * Normalize title for matching
     */
    normalizeTitle(title) {
      return title
        .toLowerCase()
        .replace(/[^\w\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    }

    /**
     * Check if current page is cart page
     */
    isCartPage() {
      const currentDomain = window.location.hostname;
      const platform = this.identifyPlatform(currentDomain);
      
      if (!platform) return false;
      
      const cartUrls = [
        '/cart',
        '/viewcart',
        '/gp/cart',
        '/checkout'
      ];
      
      return cartUrls.some(url => window.location.pathname.includes(url));
    }

    /**
     * Get cart total
     */
    getCartTotal() {
      const totalSelectors = [
        '.a-price-whole .a-offscreen',
        '._1dJ7ru ._2Kn22P',
        '.cart-total .price',
        '.total-amount',
        '.cart-summary .total'
      ];

      for (const selector of totalSelectors) {
        const element = document.querySelector(selector);
        if (element) {
          return this.extractPrice(element.textContent);
        }
      }

      return 0;
    }
  }

  /**
   * Injected Automation Helper
   * Handles direct page interactions
   */
  class InjectedAutomationHelper {
    constructor() {
      this.platforms = {
        'zepto.com': {
          addToCartSelectors: {
            button: '.add-to-cart-btn, .btn-add-to-cart',
            quantity: '.quantity-selector select',
            variant: '.variant-selector select'
          }
        },
        'blinkit.com': {
          addToCartSelectors: {
            button: '.add-to-cart, .btn-add',
            quantity: '.qty-selector select',
            variant: '.variant-option'
          }
        },
        'bigbasket.com': {
          addToCartSelectors: {
            button: '.btn-add-to-cart, .add-to-cart',
            quantity: '.qty-selector select',
            variant: '.variant-selector select'
          }
        }
      };
    }

    /**
     * Add product to cart
     */
    addProductToCart(product, quantity, platform) {
      const platformConfig = this.platforms[platform];
      if (!platformConfig) {
        throw new Error(`Unsupported platform: ${platform}`);
      }

      const selectors = platformConfig.addToCartSelectors;

      // Set quantity if selector exists
      const quantityElement = document.querySelector(selectors.quantity);
      if (quantityElement) {
        quantityElement.value = quantity;
        quantityElement.dispatchEvent(new Event('change'));
      }

      // Click add to cart button
      const addButton = document.querySelector(selectors.button);
      if (addButton) {
        addButton.click();
        return { success: true };
      } else {
        return { success: false, error: 'Add to cart button not found' };
      }
    }

    /**
     * Check if product is available
     */
    isProductAvailable() {
      const unavailableSelectors = [
        '.out-of-stock',
        '.unavailable',
        '.sold-out',
        '[data-unavailable="true"]'
      ];

      return !unavailableSelectors.some(selector => 
        document.querySelector(selector)
      );
    }

    /**
     * Get product variants
     */
    getProductVariants() {
      const variantSelectors = [
        '.variant-selector select',
        '.variant-option',
        '.size-selector select',
        '.color-selector select'
      ];

      const variants = [];
      
      variantSelectors.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
          const options = element.querySelectorAll('option');
          options.forEach(option => {
            if (option.value && option.textContent.trim()) {
              variants.push({
                value: option.value,
                text: option.textContent.trim(),
                selected: option.selected
              });
            }
          });
        }
      });

      return variants;
    }

    /**
     * Select product variant
     */
    selectVariant(variantValue) {
      const variantSelectors = [
        '.variant-selector select',
        '.variant-option',
        '.size-selector select',
        '.color-selector select'
      ];

      for (const selector of variantSelectors) {
        const element = document.querySelector(selector);
        if (element) {
          element.value = variantValue;
          element.dispatchEvent(new Event('change'));
          return true;
        }
      }

      return false;
    }
  }

  /**
   * Injected UI Helper
   * Handles UI overlays and notifications
   */
  class InjectedUIHelper {
    constructor() {
      this.overlay = null;
      this.notifications = [];
    }

    /**
     * Show overlay
     */
    showOverlay(content) {
      this.hideOverlay();

      const overlay = document.createElement('div');
      overlay.className = 'cart-compare-overlay';
      overlay.innerHTML = content;
      
      document.body.appendChild(overlay);
      this.overlay = overlay;

      // Add close functionality
      const closeBtn = overlay.querySelector('.cart-compare-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => this.hideOverlay());
      }

      // Close on overlay click
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          this.hideOverlay();
        }
      });
    }

    /**
     * Hide overlay
     */
    hideOverlay() {
      if (this.overlay) {
        this.overlay.remove();
        this.overlay = null;
      }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info', duration = 3000) {
      const notification = document.createElement('div');
      notification.className = `cart-compare-notification cart-compare-notification-${type}`;
      notification.textContent = message;
      
      document.body.appendChild(notification);
      this.notifications.push(notification);

      // Auto remove
      setTimeout(() => {
        this.removeNotification(notification);
      }, duration);
    }

    /**
     * Remove notification
     */
    removeNotification(notification) {
      if (notification && notification.parentNode) {
        notification.parentNode.removeChild(notification);
        const index = this.notifications.indexOf(notification);
        if (index > -1) {
          this.notifications.splice(index, 1);
        }
      }
    }

    /**
     * Show floating button
     */
    showFloatingButton(text, onClick) {
      const button = document.createElement('button');
      button.className = 'cart-compare-floating-btn';
      button.innerHTML = `<span class="cart-compare-floating-btn-icon">🛒</span>${text}`;
      
      button.addEventListener('click', onClick);
      document.body.appendChild(button);
      
      return button;
    }

    /**
     * Remove floating button
     */
    removeFloatingButton(button) {
      if (button && button.parentNode) {
        button.parentNode.removeChild(button);
      }
    }
  }

  // Initialize injected helpers
  window.cartCompareInjected = {
    cartExtractor: new InjectedCartExtractor(),
    automationHelper: new InjectedAutomationHelper(),
    uiHelper: new InjectedUIHelper()
  };

  // Listen for messages from content script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    
    const { type, data } = event.data;
    
    switch (type) {
      case 'EXTRACT_CART':
        try {
          const cartData = window.cartCompareInjected.cartExtractor.extractCartItems();
          window.postMessage({
            type: 'CART_EXTRACTED',
            data: cartData
          }, '*');
        } catch (error) {
          window.postMessage({
            type: 'CART_EXTRACTION_ERROR',
            error: error.message
          }, '*');
        }
        break;
        
      case 'ADD_TO_CART':
        try {
          const result = window.cartCompareInjected.automationHelper.addProductToCart(
            data.product,
            data.quantity,
            data.platform
          );
          window.postMessage({
            type: 'ADD_TO_CART_RESULT',
            data: result
          }, '*');
        } catch (error) {
          window.postMessage({
            type: 'ADD_TO_CART_ERROR',
            error: error.message
          }, '*');
        }
        break;
        
      case 'SHOW_OVERLAY':
        window.cartCompareInjected.uiHelper.showOverlay(data.content);
        break;
        
      case 'HIDE_OVERLAY':
        window.cartCompareInjected.uiHelper.hideOverlay();
        break;
        
      case 'SHOW_NOTIFICATION':
        window.cartCompareInjected.uiHelper.showNotification(
          data.message,
          data.type,
          data.duration
        );
        break;
    }
  });

  // Inject CSS styles
  const style = document.createElement('style');
  style.textContent = `
    .cart-compare-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    }
    
    .cart-compare-modal {
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 500px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
      animation: slideIn 0.3s ease-out;
    }
    
    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .cart-compare-notification {
      position: fixed;
      top: 20px;
      right: 20px;
      background: #27ae60;
      color: white;
      padding: 12px 16px;
      border-radius: 6px;
      font-size: 14px;
      z-index: 1000000;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      animation: slideInRight 0.3s ease-out;
    }
    
    .cart-compare-notification-error {
      background: #e74c3c;
    }
    
    @keyframes slideInRight {
      from {
        opacity: 0;
        transform: translateX(100%);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    
    .cart-compare-floating-btn {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 50px;
      padding: 12px 20px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
      z-index: 999998;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .cart-compare-floating-btn:hover {
      background: #5a6fd8;
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
    }
  `;
  
  document.head.appendChild(style);

})();
