/**
 * Content Script
 * Injected into cart pages. Uses CartExtractor, ProductMatcher, and CartAutomation.
 */

(async () => {
  try {
    // Ensure dependencies exist
    if (!window.CartExtractor) {
      console.error('[content.js] CartExtractor not found. Did you load js/cartExtractor.js?');
      return;
    }
    if (!window.ProductMatcher) {
      console.error('[content.js] ProductMatcher not found. Did you load js/productMatcher.js?');
      return;
    }
    if (!window.CartAutomation) {
      console.error('[content.js] CartAutomation not found. Did you load js/cartAutomation.js?');
      return;
    }

    const extractor = new window.CartExtractor();
    const matcher = new window.ProductMatcher();
    const automation = new window.CartAutomation();

    // Detect cart page
    if (!extractor.isCartPage()) {
      console.debug('[content.js] Not a cart page, skipping.');
      return;
    }

    console.debug('[content.js] Cart page detected, starting extraction.');

    // Extract cart data
    const items = await extractor.extractCartItems();
    const total = await extractor.getCartTotal();

    const cartData = {
      items,
      total,
      itemCount: items.length,
      timestamp: Date.now()
    };

    console.info('[content.js] Extracted cart data:', cartData);

    // Notify background script
    chrome.runtime.sendMessage({
      action: 'cartData',
      cartData,
      url: window.location.href
    });

    // Listen for commands from popup/background
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'extractCart') {
        // Check if it's a cart page first
        if (!extractor.isCartPage()) {
          sendResponse({ items: [], error: 'Not a cart page' });
          return true;
        }
        
        extractor.extractCartItems()
          .then(items => {
            console.log('[content.js] Extracted items:', items);
            sendResponse({ items });
          })
          .catch(err => {
            console.error('[content.js] Extraction error:', err);
            sendResponse({ items: [], error: String(err) });
          });
        return true; // keep channel open
      }

      if (request.action === 'getCartTotal') {
        extractor.getCartTotal()
          .then(total => sendResponse({ total }))
          .catch(err => sendResponse({ error: String(err) }));
        return true;
      }

      if (request.action === 'autoRemove') {
        automation.removeItems(request.criteria)
          .then(result => sendResponse({ result }))
          .catch(err => sendResponse({ error: String(err) }));
        return true;
      }

      if (request.action === 'matchProducts') {
        const matches = matcher.matchCartWithCatalog(cartData.items, request.catalog || []);
        sendResponse({ matches });
        return true;
      }

      return false; // unhandled
    });
  } catch (err) {
    console.error('[content.js] Fatal error:', err);
  }
})();
