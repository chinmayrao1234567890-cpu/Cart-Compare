# CartCompare Extension - Installation Guide

## Quick Start

### 1. Download the Extension
- Download or clone this repository
- Extract the files to a local directory

### 2. Load in Chrome/Edge
1. Open Chrome or Edge browser
2. Navigate to `chrome://extensions/` (Chrome) or `edge://extensions/` (Edge)
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. Select the `cart-compare-extension` folder
6. The extension should now appear in your extensions list

### 3. Pin the Extension
1. Click the puzzle piece icon in the browser toolbar
2. Find "CartCompare" and click the pin icon
3. The extension icon will now be visible in your toolbar

## Usage Instructions

### Basic Workflow
1. **Navigate to an e-commerce site** (Amazon, Flipkart, etc.)
2. **Add items to your cart**
3. **Click the CartCompare extension icon**
4. **View price comparisons** across different platforms
5. **Click "Add All to Cart"** on your preferred platform

### Supported Sites

#### Source Sites (Where you can extract carts)
- Amazon.in
- Flipkart.com
- Other major e-commerce platforms

#### Target Sites (Where you can build carts)
- Zepto (10-15 min delivery)
- Blinkit (10-15 min delivery)
- BigBasket (1-2 hours delivery)
- Grofers (30-45 min delivery)

## Features Overview

### 🛒 Cart Extraction
- Automatically detects cart items
- Extracts product details, prices, and quantities
- Works on supported e-commerce platforms

### 💰 Price Comparison
- Compares total cart value across platforms
- Shows potential savings and trade-offs
- Considers delivery time and seller ratings

### ⚡ One-Click Switching
- "Add All to Cart" button for easy switching
- Automated cart building on target platforms
- Fallback options when automation fails

### 🎨 User Interface
- Clean, modern popup interface
- Real-time progress tracking
- Settings panel for customization

## Troubleshooting

### Extension Not Working
1. **Check if you're on a supported site**
2. **Ensure items are in your cart**
3. **Try refreshing the page**
4. **Check browser console for errors**

### Cart Not Detected
1. **Navigate to the cart page** (not product page)
2. **Ensure cart has items**
3. **Try different supported platforms**

### Automation Fails
1. **Check if login is required**
2. **Verify product availability**
3. **Use manual cart copy as fallback**

### No Matches Found
1. **Adjust matching settings**
2. **Try different search terms**
3. **Check product title similarity**

## Settings Configuration

### Access Settings
1. Click the CartCompare extension icon
2. Click the settings gear icon (⚙️)
3. Adjust preferences as needed

### Available Settings
- **Brand Loyalty** (0-100%): How much to prioritize brand consistency
- **Delivery Speed** (0-100%): Priority for faster delivery
- **Seller Rating** (0-100%): Importance of seller ratings
- **Price Weight** (0-100%): Emphasis on price savings

## Security & Privacy

### Data Protection
- No sensitive data is stored
- All processing happens client-side
- No user credentials are saved
- Automatic data sanitization

### Privacy Compliance
- GDPR compliant for EU users
- CCPA compliant for California users
- Transparent data usage policies

## Advanced Features

### Manual Override
- Review matched products before adding
- Modify quantities and selections
- Choose alternative products

### Cart Copy
- Copy cart data to clipboard
- Share cart information
- Manual processing options

### Error Recovery
- Clear error messages
- Guided recovery instructions
- Multiple fallback strategies

## Development Mode

### Enable Debug Logging
1. Open browser console (F12)
2. Type: `localStorage.debug = 'true'`
3. Reload the extension
4. Check console for detailed logs

### View Error Logs
1. Open browser console
2. Type: `localStorage.getItem('cartCompareErrorLogs')`
3. View detailed error information

## Uninstallation

### Remove Extension
1. Go to `chrome://extensions/`
2. Find "CartCompare"
3. Click "Remove"
4. Confirm removal

### Clear Data
1. Go to `chrome://settings/content/all`
2. Search for "CartCompare"
3. Click "Clear data"

## Support

### Getting Help
- Check this installation guide
- Review the main README.md
- Check browser console for errors
- Report issues on GitHub

### Common Issues
- **Permission denied**: Grant necessary permissions
- **Cart not loading**: Check if site is supported
- **Automation fails**: Use manual fallback options

## Updates

### Manual Updates
1. Download latest version
2. Remove old extension
3. Load new version
4. Settings will be preserved

### Automatic Updates
- Currently not available
- Check GitHub for new releases
- Follow installation steps for updates

## Browser Compatibility

### Supported Browsers
- Chrome 88+
- Edge 88+
- Other Chromium-based browsers

### Unsupported Browsers
- Firefox (coming soon)
- Safari (coming soon)
- Internet Explorer

## Performance Tips

### Optimal Usage
- Use on supported e-commerce sites
- Ensure stable internet connection
- Close unnecessary browser tabs
- Keep extension updated

### Memory Usage
- Extension uses minimal memory
- No background processes
- Automatic cleanup of temporary data

---

**Need more help?** Check the main README.md or create an issue on GitHub.
