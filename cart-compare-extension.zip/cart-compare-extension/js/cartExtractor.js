/**
 * Cart Extraction Module
 * Handles DOM parsing and cart item extraction from various e-commerce platforms
 */

class CartExtractor {
  constructor() {
    this.platforms = {
      'amazon.in': {
        cartSelectors: {
          items: '[data-item-id]',
          title: '[data-item-id] h3 a, [data-item-id] .a-size-medium',
          price: '.a-price-whole, .a-offscreen',
          quantity: '[data-item-id] .a-dropdown-prompt, [data-item-id] .a-spacing-small select',
          image: '[data-item-id] img',
          removeButton: '[data-item-id] .a-button-delete'
        },
        cartUrl: '/cart/localmarket'
      },
      'flipkart.com': {
        cartSelectors: {
          items: '.IIdQZO ._1AtVbE',
          title: '._2Kn22P',
          price: '._30jeq3',
          quantity: '._3dY_ZR select',
          image: '._396cs4',
          removeButton: '._3dsJAO'
        },
        cartUrl: '/viewcart'
      },
      'zepto.com': {
        cartSelectors: {
          items: '.cart-item',
          title: '.product-title',
          price: '.price',
          quantity: '.quantity-selector select',
          image: '.product-image img',
          removeButton: '.remove-item'
        },
        cartUrl: '?cart=open'
      },
      'bigbasket.com': {
        cartSelectors: {
          items: '.item',
          title: '.item-name',
          price: '.price',
          quantity: '.qty-selector select',
          image: '.item-img img',
          removeButton: '.remove-item'
        },
        cartUrl: '/basket/'
      },
      'swiggy.com': {
        cartSelectors: {
          items: '.cart-item',
          title: '.product-name',
          price: '.price',
          quantity: '.qty-selector select',
          image: '.product-img img',
          removeButton: '.remove-btn'
        },
        cartUrl: '/instamart/cart'
      },
      'blinkit.com': {
        cartSelectors: {
          items: '.cart-item',
          title: '.product-name',
          price: '.price',
          quantity: '.qty-selector select',
          image: '.product-img img',
          removeButton: '.remove-btn'
        },
        // ⚠️ Blinkit doesn’t change URL, so we’ll detect cart via DOM
        cartUrl: null
      }
    };
  }

  /**
   * Extract cart items from current page
   * @returns {Promise<Array>} Array of cart items
   */
  async extractCartItems() {
    const currentDomain = window.location.hostname;
    const platform = this.identifyPlatform(currentDomain);
    
    if (!platform) {
      throw new Error('Unsupported platform');
    }

    const cartData = await this.parseCartItems(platform);
    return this.normalizeCartData(cartData);
  }

  /**
   * Identify the e-commerce platform based on domain
   * @param {string} domain 
   * @returns {string|null}
   */
  identifyPlatform(domain) {
    for (const platform in this.platforms) {
      if (domain.includes(platform)) {
        return platform;
      }
    }
    return null;
  }

  /**
   * Parse cart items using platform-specific selectors
   */
  async parseCartItems(platform) {
    const selectors = this.platforms[platform].cartSelectors;
    const items = [];

    await this.waitForCartLoad(selectors.items);

    const itemElements = document.querySelectorAll(selectors.items);
    
    for (const itemElement of itemElements) {
      try {
        const item = await this.extractItemData(itemElement, selectors);
        if (item && item.title && item.price) {
          items.push(item);
        }
      } catch (error) {
        console.warn('Failed to extract item:', error);
      }
    }

    return items;
  }

  async extractItemData(itemElement, selectors) {
    const titleElement = itemElement.querySelector(selectors.title);
    const priceElement = itemElement.querySelector(selectors.price);
    const quantityElement = itemElement.querySelector(selectors.quantity);
    const imageElement = itemElement.querySelector(selectors.image);

    const title = titleElement ? titleElement.textContent.trim() : '';
    const price = this.extractPrice(priceElement ? priceElement.textContent : '');
    const quantity = quantityElement ? parseInt(quantityElement.value || quantityElement.textContent) : 1;
    const imageUrl = imageElement ? imageElement.src || imageElement.getAttribute('data-src') : '';
    const productUrl = titleElement ? titleElement.href : '';

    return {
      title,
      price,
      quantity,
      imageUrl,
      productUrl,
      originalElement: itemElement
    };
  }

  extractPrice(priceText) {
    if (!priceText) return 0;
    const numericPrice = priceText.replace(/[^\d.,]/g, '');
    const price = parseFloat(numericPrice.replace(',', ''));
    return isNaN(price) ? 0 : price;
  }

  async waitForCartLoad(itemSelector) {
    return new Promise((resolve) => {
      const checkForItems = () => {
        const items = document.querySelectorAll(itemSelector);
        if (items.length > 0) {
          resolve();
        } else {
          setTimeout(checkForItems, 500);
        }
      };
      checkForItems();
    });
  }

  normalizeCartData(cartData) {
    return cartData.map(item => ({
      ...item,
      id: this.generateItemId(item),
      normalizedTitle: this.normalizeTitle(item.title),
      totalPrice: item.price * item.quantity
    }));
  }

  generateItemId(item) {
    return btoa(item.title + item.price).replace(/[^a-zA-Z0-9]/g, '');
  }

  normalizeTitle(title) {
    return title
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Check if current page is a cart page
   */
  isCartPage() {
    const domain = window.location.hostname;
    const platform = this.identifyPlatform(domain);
    if (!platform) return false;

    // Check for cart indicators in DOM first
    const cartIndicators = [
      '.cart-item', '.cart-summary', '[data-test-id="cart-container"]',
      '.shopping-cart', '.cart-container', '.cart-page',
      '[data-item-id]', // Amazon cart items
      '._1AtVbE', // Flipkart cart items
      '.cart-item', '.item' // Generic cart items
    ];
    
    const hasCartItems = cartIndicators.some(selector => 
      document.querySelector(selector) !== null
    );

    if (hasCartItems) return true;

    // Check URL patterns
    const cartUrl = this.platforms[platform].cartUrl;
    if (cartUrl && window.location.href.includes(cartUrl)) {
      return true;
    }

    // Platform-specific checks
    if (platform === 'blinkit.com') {
      return !!document.querySelector('.cart-item, .cart-summary, [data-test-id="cart-container"]');
    }

    if (platform === 'zepto.com') {
      return window.location.search.includes('cart=open');
    }

    // Check for common cart page patterns
    const cartPagePatterns = ['/cart', '/basket', '/bag', '/checkout'];
    return cartPagePatterns.some(pattern => 
      window.location.pathname.includes(pattern)
    );
  }

  async getCartTotal() {
    const totalSelectors = [
      '.a-price-whole .a-offscreen',
      '._1dJ7ru ._2Kn22P',
      '.cart-total .price',
      '.total-amount',
      '.cart-summary .total'
    ];

    for (const selector of totalSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        return this.extractPrice(element.textContent);
      }
    }

    return 0;
  }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CartExtractor;
} else {
  window.CartExtractor = CartExtractor;
}
