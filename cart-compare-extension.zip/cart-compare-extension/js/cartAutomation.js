/**
 * Cart Automation Module
 * Handles automated cart building and URL generation
 */

class CartAutomation {
  constructor() {
    this.platforms = {
      'amazon.com': {
        name: 'Amazon',
        baseUrl: 'https://www.amazon.com',
        cartUrl: '/cart',
        addToCartSelectors: {
          button: '#add-to-cart-button, .add-to-cart-button',
          quantity: '#quantity',
          variant: '.a-button-dropdown'
        },
        prefillUrlPattern: '/dp/{id}?quantity={qty}'
      },
      'walmart.com': {
        name: 'Walmart',
        baseUrl: 'https://www.walmart.com',
        cartUrl: '/cart',
        addToCartSelectors: {
          button: '[data-testid="add-to-cart-button"], .add-to-cart-button',
          quantity: '[data-testid="quantity"]',
          variant: '.variant-selector'
        },
        prefillUrlPattern: '/ip/{id}?quantity={qty}'
      },
      'target.com': {
        name: 'Target',
        baseUrl: 'https://www.target.com',
        cartUrl: '/cart',
        addToCartSelectors: {
          button: '[data-test="addToCartButton"], .add-to-cart-button',
          quantity: '[data-test="quantity"]',
          variant: '.variant-selector'
        },
        prefillUrlPattern: '/p/{id}?quantity={qty}'
      }
    };
  }

  /**
   * Build cart on target platform
   * @param {Array} matchedProducts 
   * @param {string} platform 
   * @returns {Promise<Object>}
   */
  async buildCart(matchedProducts, platform) {
    const platformConfig = this.platforms[platform];
    if (!platformConfig) {
      throw new Error(`Unsupported platform: ${platform}`);
    }

    try {
      // Try URL-based cart building first
      const cartUrl = await this.generateCartUrl(matchedProducts, platform);
      if (cartUrl) {
        return {
          success: true,
          method: 'url',
          cartUrl: cartUrl,
          message: `Cart ready on ${platformConfig.name}!`
        };
      }
    } catch (error) {
      console.warn('URL-based cart building failed:', error);
    }

    // Fallback to automation
    return await this.automateCartBuilding(matchedProducts, platform);
  }

  /**
   * Generate pre-filled cart URL
   * @param {Array} matchedProducts 
   * @param {string} platform 
   * @returns {Promise<string|null>}
   */
  async generateCartUrl(matchedProducts, platform) {
    const platformConfig = this.platforms[platform];
    
    // Check if platform supports URL-based cart building
    if (!platformConfig.prefillUrlPattern) {
      return null;
    }

    const cartItems = matchedProducts.map(match => ({
      id: match.matchedProduct.id,
      quantity: match.originalItem.quantity
    }));

    // Generate cart URL with all items
    const baseUrl = platformConfig.baseUrl + platformConfig.cartUrl;
    const queryParams = this.buildCartQueryParams(cartItems, platform);
    
    return `${baseUrl}?${queryParams}`;
  }

  /**
   * Build query parameters for cart URL
   * @param {Array} cartItems 
   * @param {string} platform 
   * @returns {string}
   */
  buildCartQueryParams(cartItems, platform) {
    const platformConfig = this.platforms[platform];
    const params = new URLSearchParams();

    cartItems.forEach((item, index) => {
      params.append(`items[${index}][id]`, item.id);
      params.append(`items[${index}][quantity]`, item.quantity);
    });

    return params.toString();
  }

  /**
   * Automate cart building using browser automation
   * @param {Array} matchedProducts 
   * @param {string} platform 
   * @returns {Promise<Object>}
   */
  async automateCartBuilding(matchedProducts, platform) {
    const platformConfig = this.platforms[platform];
    const results = {
      success: true,
      method: 'automation',
      addedItems: [],
      failedItems: [],
      message: ''
    };

    // Open platform in new tab
    const tab = await this.openPlatformTab(platform);
    
    try {
      for (const match of matchedProducts) {
        try {
          await this.addProductToCart(match, platform, tab.id);
          results.addedItems.push(match);
        } catch (error) {
          console.warn(`Failed to add ${match.originalItem.title}:`, error);
          results.failedItems.push({
            ...match,
            error: error.message
          });
        }
      }

      // Navigate to cart
      await this.navigateToCart(platform, tab.id);
      
      results.message = `Added ${results.addedItems.length} items to ${platformConfig.name} cart`;
      
      if (results.failedItems.length > 0) {
        results.message += `. ${results.failedItems.length} items failed to add.`;
      }

    } catch (error) {
      results.success = false;
      results.message = `Failed to build cart: ${error.message}`;
    }

    return results;
  }

  /**
   * Open platform in new tab
   * @param {string} platform 
   * @returns {Promise<Object>}
   */
  async openPlatformTab(platform) {
    const platformConfig = this.platforms[platform];
    
    return new Promise((resolve, reject) => {
      chrome.tabs.create({
        url: platformConfig.baseUrl,
        active: false
      }, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(tab);
        }
      });
    });
  }

  /**
   * Add single product to cart
   * @param {Object} match 
   * @param {string} platform 
   * @param {number} tabId 
   * @returns {Promise<void>}
   */
  async addProductToCart(match, platform, tabId) {
    const product = match.matchedProduct;
    const quantity = match.originalItem.quantity;

    // Navigate to product page
    await this.navigateToProduct(product.productUrl, tabId);
    
    // Wait for page to load
    await this.waitForPageLoad(tabId);

    // Execute add to cart script
    await this.executeAddToCartScript(product, quantity, platform, tabId);
  }

  /**
   * Navigate to product page
   * @param {string} productUrl 
   * @param {number} tabId 
   * @returns {Promise<void>}
   */
  async navigateToProduct(productUrl, tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.update(tabId, {
        url: productUrl,
        active: false
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Wait for page to load
   * @param {number} tabId 
   * @returns {Promise<void>}
   */
  async waitForPageLoad(tabId) {
    return new Promise((resolve) => {
      const checkComplete = () => {
        chrome.tabs.get(tabId, (tab) => {
          if (tab.status === 'complete') {
            resolve();
          } else {
            setTimeout(checkComplete, 500);
          }
        });
      };
      checkComplete();
    });
  }

  /**
   * Execute add to cart script in tab
   * @param {Object} product 
   * @param {number} quantity 
   * @param {string} platform 
   * @param {number} tabId 
   * @returns {Promise<void>}
   */
  async executeAddToCartScript(product, quantity, platform, tabId) {
    const platformConfig = this.platforms[platform];
    const script = this.generateAddToCartScript(product, quantity, platformConfig);

    return new Promise((resolve, reject) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: this.injectAddToCartScript,
        args: [script, product, quantity, platformConfig]
      }, (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (results && results[0] && results[0].result.success) {
          resolve();
        } else {
          reject(new Error('Failed to add product to cart'));
        }
      });
    });
  }

  /**
   * Generate add to cart script
   * @param {Object} product 
   * @param {number} quantity 
   * @param {Object} platformConfig 
   * @returns {string}
   */
  generateAddToCartScript(product, quantity, platformConfig) {
    return `
      (function() {
        try {
          // Set quantity if selector exists
          const quantitySelector = '${platformConfig.addToCartSelectors.quantity}';
          const quantityElement = document.querySelector(quantitySelector);
          if (quantityElement) {
            quantityElement.value = ${quantity};
            quantityElement.dispatchEvent(new Event('change'));
          }

          // Click add to cart button
          const addButtonSelector = '${platformConfig.addToCartSelectors.button}';
          const addButton = document.querySelector(addButtonSelector);
          
          if (addButton) {
            addButton.click();
            return { success: true };
          } else {
            return { success: false, error: 'Add to cart button not found' };
          }
        } catch (error) {
          return { success: false, error: error.message };
        }
      })();
    `;
  }

  /**
   * Inject add to cart script (executed in page context)
   * @param {string} script 
   * @param {Object} product 
   * @param {number} quantity 
   * @param {Object} platformConfig 
   * @returns {Object}
   */
  injectAddToCartScript(script, product, quantity, platformConfig) {
    try {
      // Set quantity if selector exists
      const quantitySelector = platformConfig.addToCartSelectors.quantity;
      const quantityElement = document.querySelector(quantitySelector);
      if (quantityElement) {
        quantityElement.value = quantity;
        quantityElement.dispatchEvent(new Event('change'));
      }

      // Click add to cart button
      const addButtonSelector = platformConfig.addToCartSelectors.button;
      const addButton = document.querySelector(addButtonSelector);
      
      if (addButton) {
        addButton.click();
        return { success: true };
      } else {
        return { success: false, error: 'Add to cart button not found' };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Navigate to cart page
   * @param {string} platform 
   * @param {number} tabId 
   * @returns {Promise<void>}
   */
  async navigateToCart(platform, tabId) {
    const platformConfig = this.platforms[platform];
    const cartUrl = platformConfig.baseUrl + platformConfig.cartUrl;

    return new Promise((resolve, reject) => {
      chrome.tabs.update(tabId, {
        url: cartUrl,
        active: true
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Generate cart copy data for clipboard
   * @param {Array} matchedProducts 
   * @param {string} platform 
   * @returns {string}
   */
  generateCartCopyData(matchedProducts, platform) {
    const platformConfig = this.platforms[platform];
    const cartData = {
      platform: platformConfig.name,
      items: matchedProducts.map(match => ({
        title: match.matchedProduct.title,
        price: match.matchedProduct.price,
        quantity: match.originalItem.quantity,
        url: match.matchedProduct.productUrl
      })),
      totalSavings: matchedProducts.reduce((sum, match) => sum + match.savings, 0)
    };

    return JSON.stringify(cartData, null, 2);
  }

  /**
   * Copy cart data to clipboard
   * @param {string} data 
   * @returns {Promise<boolean>}
   */
  async copyToClipboard(data) {
    try {
      await navigator.clipboard.writeText(data);
      return true;
    } catch (error) {
      console.warn('Clipboard API failed, trying fallback:', error);
      return this.fallbackCopyToClipboard(data);
    }
  }

  /**
   * Fallback clipboard copy method
   * @param {string} data 
   * @returns {boolean}
   */
  fallbackCopyToClipboard(data) {
    try {
      const textArea = document.createElement('textarea');
      textArea.value = data;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      const result = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      return result;
    } catch (error) {
      console.error('Fallback clipboard copy failed:', error);
      return false;
    }
  }

  /**
   * Check if platform supports automation
   * @param {string} platform 
   * @returns {boolean}
   */
  supportsAutomation(platform) {
    return this.platforms[platform] && this.platforms[platform].addToCartSelectors;
  }

  /**
   * Get platform capabilities
   * @param {string} platform 
   * @returns {Object}
   */
  getPlatformCapabilities(platform) {
    const platformConfig = this.platforms[platform];
    if (!platformConfig) return null;

    return {
      name: platformConfig.name,
      supportsUrlPrefill: !!platformConfig.prefillUrlPattern,
      supportsAutomation: !!platformConfig.addToCartSelectors,
      baseUrl: platformConfig.baseUrl
    };
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CartAutomation;
} else {
  window.CartAutomation = CartAutomation;
}
