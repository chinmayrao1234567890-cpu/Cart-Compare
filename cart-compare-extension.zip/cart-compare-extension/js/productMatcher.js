/**
 * Product Matching and Comparison Module
 * Handles product matching across different e-commerce platforms
 */

class ProductMatcher {
  constructor() {
    this.platforms = {
      'amazon.com': {
        name: 'Amazon',
        baseUrl: 'https://www.amazon.com',
        searchEndpoint: '/s',
        apiEndpoint: 'https://completion.amazon.com/api/2017/suggestions',
        deliveryTime: '1-2 days',
        rating: 4.5,
        hasAPI: true
      },
      'amazon.in': {
        name: 'Amazon India',
        baseUrl: 'https://www.amazon.in',
        searchEndpoint: '/s',
        apiEndpoint: 'https://completion.amazon.in/api/2017/suggestions',
        deliveryTime: '1-2 days',
        rating: 4.5,
        hasAPI: true
      },
      'walmart.com': {
        name: 'Walmart',
        baseUrl: 'https://www.walmart.com',
        searchEndpoint: '/search',
        apiEndpoint: 'https://www.walmart.com/typeahead/v2/complete',
        deliveryTime: '2-3 days',
        rating: 4.3,
        hasAPI: true
      },
      'flipkart.com': {
        name: 'Flipkart',
        baseUrl: 'https://www.flipkart.com',
        searchEndpoint: '/search',
        apiEndpoint: 'https://1.rome.api.flipkart.com/api/3/page/dynamic',
        deliveryTime: '1-2 days',
        rating: 4.4,
        hasAPI: true
      }
    };

    this.userPreferences = {
      brandLoyalty: 0.7, // 0-1 scale
      deliverySpeed: 0.6, // 0-1 scale
      sellerRating: 0.8, // 0-1 scale
      priceWeight: 0.9 // 0-1 scale
    };
  }

  /**
   * Find matching products across platforms
   * @param {Array} cartItems 
   * @returns {Promise<Object>}
   */
  async findMatchingProducts(cartItems) {
    const results = {};
    
    for (const platform in this.platforms) {
      try {
        results[platform] = await this.searchProductsOnPlatform(cartItems, platform);
      } catch (error) {
        console.warn(`Failed to search on ${platform}:`, error);
        results[platform] = { error: error.message, matches: [] };
      }
    }

    return this.rankPlatforms(results, cartItems);
  }

  /**
   * Search for products on a specific platform
   * @param {Array} cartItems 
   * @param {string} platform 
   * @returns {Promise<Object>}
   */
  async searchProductsOnPlatform(cartItems, platform) {
    const platformConfig = this.platforms[platform];
    const matches = [];

    for (const item of cartItems) {
      try {
        const searchResults = await this.searchProduct(item, platform);
        const bestMatch = this.findBestMatch(item, searchResults);
        
        if (bestMatch) {
          matches.push({
            originalItem: item,
            matchedProduct: bestMatch,
            confidence: bestMatch.confidence,
            priceDifference: bestMatch.price - item.price,
            savings: item.totalPrice - (bestMatch.price * item.quantity)
          });
        }
      } catch (error) {
        console.warn(`Failed to search for ${item.title} on ${platform}:`, error);
      }
    }

    return {
      platform: platformConfig.name,
      matches,
      totalSavings: matches.reduce((sum, match) => sum + match.savings, 0),
      deliveryTime: platformConfig.deliveryTime,
      rating: platformConfig.rating
    };
  }

  /**
   * Search for a single product on platform
   * @param {Object} item 
   * @param {string} platform 
   * @returns {Promise<Array>}
   */
  async searchProduct(item, platform) {
    const platformConfig = this.platforms[platform];
    const searchQuery = this.buildSearchQuery(item);
    
    // Try API first, fallback to web scraping
    try {
      return await this.searchViaAPI(searchQuery, platform);
    } catch (error) {
      console.warn(`API search failed for ${platform}, trying web scraping`);
      return await this.searchViaWebScraping(searchQuery, platform);
    }
  }

  /**
   * Build search query from cart item
   * @param {Object} item 
   * @returns {string}
   */
  buildSearchQuery(item) {
    // Extract key terms from product title
    const title = item.normalizedTitle || item.title || '';
    if (!title) {
      console.warn('No title found for item:', item);
      return '';
    }
    const words = title.split(' ').filter(word => word.length > 2);
    
    // Remove common stop words
    const stopWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
    const filteredWords = words.filter(word => !stopWords.includes(word));
    
    return filteredWords.slice(0, 5).join(' '); // Use top 5 words
  }

  /**
   * Search via platform API
   * @param {string} query 
   * @param {string} platform 
   * @returns {Promise<Array>}
   */
  async searchViaAPI(query, platform) {
    const platformConfig = this.platforms[platform];
    const url = `${platformConfig.baseUrl}${platformConfig.apiEndpoint}?q=${encodeURIComponent(query)}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (compatible; CartCompare/1.0)'
      }
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();
    return this.parseAPIResponse(data, platform);
  }

  /**
   * Search via web scraping
   * @param {string} query 
   * @param {string} platform 
   * @returns {Promise<Array>}
   */
  async searchViaWebScraping(query, platform) {
    const platformConfig = this.platforms[platform];
    const searchUrl = `${platformConfig.baseUrl}${platformConfig.searchEndpoint}?q=${encodeURIComponent(query)}`;
    
    // This would be handled by the background script
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        action: 'scrapeSearchResults',
        url: searchUrl,
        platform: platform
      }, (response) => {
        if (response.success) {
          resolve(this.parseScrapedResults(response.data, platform));
        } else {
          reject(new Error(response.error));
        }
      });
    });
  }

  /**
   * Parse API response
   * @param {Object} data 
   * @param {string} platform 
   * @returns {Array}
   */
  parseAPIResponse(data, platform) {
    const products = data.products || data.items || data.results || [];
    
    return products.map(product => ({
      id: product.id || product.sku,
      title: product.title || product.name,
      price: this.extractPrice(product.price || product.mrp),
      imageUrl: product.image || product.imageUrl,
      productUrl: product.url || product.link,
      brand: product.brand,
      category: product.category,
      rating: product.rating || 0,
      availability: product.availability || 'in_stock',
      platform: platform
    }));
  }

  /**
   * Parse scraped search results
   * @param {string} html 
   * @param {string} platform 
   * @returns {Array}
   */
  parseScrapedResults(html, platform) {
    console.log(`Parsing scraped results for ${platform}`);
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    const productSelectors = this.getProductSelectors(platform);
    console.log(`Using selectors for ${platform}:`, productSelectors);
    
    const productElements = doc.querySelectorAll(productSelectors.container);
    console.log(`Found ${productElements.length} product elements`);
    
    const products = Array.from(productElements).map((element, index) => {
      const title = this.extractText(element, productSelectors.title);
      const priceText = this.extractText(element, productSelectors.price);
      const price = this.extractPrice(priceText);
      
      console.log(`Product ${index}: title="${title}", priceText="${priceText}", price=${price}`);
      
      return {
        id: this.extractText(element, productSelectors.id) || Math.random().toString(36),
        title: title,
        price: price,
        imageUrl: this.extractAttribute(element, productSelectors.image, 'src'),
        productUrl: this.extractAttribute(element, productSelectors.link, 'href'),
        brand: this.extractText(element, productSelectors.brand),
        platform: platform
      };
    }).filter(product => {
      const isValid = product.title && product.title.length > 0 && product.price > 0;
      if (!isValid) {
        console.log(`Filtered out product: title="${product.title}", price=${product.price}`);
      }
      return isValid;
    });
    
    // If no products found, create mock data for testing
    if (products.length === 0) {
      console.log(`No products found for ${platform}, creating mock data`);
      return [{
        id: `mock_${platform}_${Date.now()}`,
        title: 'Mock Product (Search Failed)',
        price: 99.99,
        imageUrl: '',
        productUrl: '#',
        brand: 'Mock Brand',
        platform: platform
      }];
    }
    
    console.log(`Final products for ${platform}:`, products);
    return products;
  }

  /**
   * Get platform-specific product selectors
   * @param {string} platform 
   * @returns {Object}
   */
  getProductSelectors(platform) {
    const selectors = {
      'amazon.com': {
        container: '[data-component-type="s-search-result"], .s-result-item',
        title: 'h2 a span, .a-size-medium, .a-color-base',
        price: '.a-price-whole, .a-offscreen, .a-price-range',
        image: '.s-image',
        link: 'h2 a',
        brand: '.a-size-base-plus'
      },
      'amazon.in': {
        container: '[data-component-type="s-search-result"], .s-result-item',
        title: 'h2 a span, .a-size-medium, .a-color-base',
        price: '.a-price-whole, .a-offscreen, .a-price-range',
        image: '.s-image',
        link: 'h2 a',
        brand: '.a-size-base-plus'
      },
      'walmart.com': {
        container: '[data-testid="item-stack"], .item-stack',
        title: '[data-testid="product-title"], .product-title',
        price: '.price-current, .price-group',
        image: '.product-image img',
        link: '[data-testid="product-title"]',
        brand: '.product-brand'
      },
      'flipkart.com': {
        container: '._1AtVbE, .IIdQZO ._1AtVbE',
        title: '._2Kn22P, ._2B_pmu',
        price: '._30jeq3, ._1dJ7ru ._2Kn22P',
        image: '._396cs4',
        link: '._2Kn22P',
        brand: '._2WkVRV'
      }
    };

    return selectors[platform] || selectors['amazon.com'];
  }

  /**
   * Find best matching product from search results
   * @param {Object} originalItem 
   * @param {Array} searchResults 
   * @returns {Object|null}
   */
  findBestMatch(originalItem, searchResults) {
    if (!searchResults || searchResults.length === 0) return null;

    let bestMatch = null;
    let bestScore = 0;

    for (const product of searchResults) {
      const score = this.calculateMatchScore(originalItem, product);
      if (score > bestScore && score > 0.3) { // Minimum confidence threshold
        bestScore = score;
        bestMatch = { ...product, confidence: score };
      }
    }

    return bestMatch;
  }

  /**
   * Calculate match score between original item and potential match
   * @param {Object} originalItem 
   * @param {Object} product 
   * @returns {number}
   */
  calculateMatchScore(originalItem, product) {
    const titleScore = this.calculateTitleSimilarity(originalItem.title, product.title);
    const priceScore = this.calculatePriceSimilarity(originalItem.price, product.price);
    const imageScore = this.calculateImageSimilarity(originalItem.imageUrl, product.imageUrl);
    
    // Weighted average
    const totalScore = (titleScore * 0.6) + (priceScore * 0.3) + (imageScore * 0.1);
    
    return Math.min(totalScore, 1.0);
  }

  /**
   * Calculate title similarity using Levenshtein distance
   * @param {string} title1 
   * @param {string} title2 
   * @returns {number}
   */
  calculateTitleSimilarity(title1, title2) {
    if (!title1 || !title2) return 0;
    
    const normalized1 = title1.toLowerCase().trim();
    const normalized2 = title2.toLowerCase().trim();
    
    if (normalized1 === normalized2) return 1.0;
    
    const distance = this.levenshteinDistance(normalized1, normalized2);
    const maxLength = Math.max(normalized1.length, normalized2.length);
    
    return 1 - (distance / maxLength);
  }

  /**
   * Calculate price similarity
   * @param {number} price1 
   * @param {number} price2 
   * @returns {number}
   */
  calculatePriceSimilarity(price1, price2) {
    if (!price1 || !price2) return 0;
    
    const difference = Math.abs(price1 - price2);
    const average = (price1 + price2) / 2;
    
    return Math.max(0, 1 - (difference / average));
  }

  /**
   * Calculate image similarity (placeholder - would use image comparison API)
   * @param {string} image1 
   * @param {string} image2 
   * @returns {number}
   */
  calculateImageSimilarity(image1, image2) {
    // Placeholder - in real implementation, would use image comparison
    return 0.5;
  }

  /**
   * Calculate Levenshtein distance between two strings
   * @param {string} str1 
   * @param {string} str2 
   * @returns {number}
   */
  levenshteinDistance(str1, str2) {
    const matrix = [];
    
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    
    return matrix[str2.length][str1.length];
  }

  /**
   * Rank platforms based on total savings and user preferences
   * @param {Object} results 
   * @param {Array} cartItems 
   * @returns {Object}
   */
  rankPlatforms(results, cartItems) {
    const rankedPlatforms = [];
    
    for (const platform in results) {
      const result = results[platform];
      if (result.error) continue;
      
      const totalSavings = result.totalSavings;
      const originalTotal = cartItems.reduce((sum, item) => sum + item.totalPrice, 0);
      const savingsPercentage = (totalSavings / originalTotal) * 100;
      
      const score = this.calculatePlatformScore(result, savingsPercentage);
      
      rankedPlatforms.push({
        ...result,
        platform,
        score,
        savingsPercentage
      });
    }
    
    return rankedPlatforms.sort((a, b) => b.score - a.score);
  }

  /**
   * Calculate platform score based on multiple factors
   * @param {Object} result 
   * @param {number} savingsPercentage 
   * @returns {number}
   */
  calculatePlatformScore(result, savingsPercentage) {
    const priceScore = Math.min(savingsPercentage / 20, 1) * this.userPreferences.priceWeight;
    const deliveryScore = this.calculateDeliveryScore(result.deliveryTime) * this.userPreferences.deliverySpeed;
    const ratingScore = (result.rating / 5) * this.userPreferences.sellerRating;
    
    return (priceScore + deliveryScore + ratingScore) / 3;
  }

  /**
   * Calculate delivery score based on delivery time
   * @param {string} deliveryTime 
   * @returns {number}
   */
  calculateDeliveryScore(deliveryTime) {
    const timeMap = {
      '10-15 min': 1.0,
      '30-45 min': 0.8,
      '1-2 hours': 0.6,
      '2-4 hours': 0.4,
      '1-2 days': 0.2
    };
    
    return timeMap[deliveryTime] || 0.5;
  }

  /**
   * Extract text content from element
   * @param {Element} element 
   * @param {string} selector 
   * @returns {string}
   */
  extractText(element, selector) {
    const target = element.querySelector(selector);
    return target ? target.textContent.trim() : '';
  }

  /**
   * Extract attribute from element
   * @param {Element} element 
   * @param {string} selector 
   * @param {string} attribute 
   * @returns {string}
   */
  extractAttribute(element, selector, attribute) {
    const target = element.querySelector(selector);
    return target ? target.getAttribute(attribute) : '';
  }

  /**
   * Extract price from text
   * @param {string} priceText 
   * @returns {number}
   */
  extractPrice(priceText) {
    if (!priceText) return 0;
    
    const numericPrice = priceText.replace(/[^\d.,]/g, '');
    const price = parseFloat(numericPrice.replace(',', ''));
    
    return isNaN(price) ? 0 : price;
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProductMatcher;
} else {
  window.ProductMatcher = ProductMatcher;
}
