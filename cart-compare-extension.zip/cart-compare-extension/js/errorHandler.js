/**
 * Error Handling and Fallback Mechanisms
 * Centralized error handling for the extension
 */

class ErrorHandler {
  constructor() {
    this.errorTypes = {
      NETWORK_ERROR: 'NETWORK_ERROR',
      PARSING_ERROR: 'PARSING_ERROR',
      AUTOMATION_ERROR: 'AUTOMATION_ERROR',
      PERMISSION_ERROR: 'PERMISSION_ERROR',
      PLATFORM_ERROR: 'PLATFORM_ERROR',
      UNKNOWN_ERROR: 'UNKNOWN_ERROR'
    };
    
    this.fallbackStrategies = new Map();
    this.initializeFallbackStrategies();
  }

  /**
   * Initialize fallback strategies for different error types
   */
  initializeFallbackStrategies() {
    this.fallbackStrategies.set(this.errorTypes.NETWORK_ERROR, this.handleNetworkError);
    this.fallbackStrategies.set(this.errorTypes.PARSING_ERROR, this.handleParsingError);
    this.fallbackStrategies.set(this.errorTypes.AUTOMATION_ERROR, this.handleAutomationError);
    this.fallbackStrategies.set(this.errorTypes.PERMISSION_ERROR, this.handlePermissionError);
    this.fallbackStrategies.set(this.errorTypes.PLATFORM_ERROR, this.handlePlatformError);
    this.fallbackStrategies.set(this.errorTypes.UNKNOWN_ERROR, this.handleUnknownError);
  }

  /**
   * Handle errors with appropriate fallback strategies
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handleError(error, context = {}) {
    const errorType = this.classifyError(error);
    const fallbackStrategy = this.fallbackStrategies.get(errorType);
    
    console.error(`[${errorType}] ${error.message}`, { error, context });
    
    try {
      if (fallbackStrategy) {
        return await fallbackStrategy.call(this, error, context);
      } else {
        return await this.handleUnknownError(error, context);
      }
    } catch (fallbackError) {
      console.error('Fallback strategy failed:', fallbackError);
      return this.createErrorResponse(error, 'Fallback strategy failed');
    }
  }

  /**
   * Classify error type based on error properties
   * @param {Error} error 
   * @returns {string}
   */
  classifyError(error) {
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      return this.errorTypes.NETWORK_ERROR;
    }
    
    if (error.message.includes('parsing') || error.message.includes('parse')) {
      return this.errorTypes.PARSING_ERROR;
    }
    
    if (error.message.includes('automation') || error.message.includes('script')) {
      return this.errorTypes.AUTOMATION_ERROR;
    }
    
    if (error.message.includes('permission') || error.message.includes('denied')) {
      return this.errorTypes.PERMISSION_ERROR;
    }
    
    if (error.message.includes('platform') || error.message.includes('unsupported')) {
      return this.errorTypes.PLATFORM_ERROR;
    }
    
    return this.errorTypes.UNKNOWN_ERROR;
  }

  /**
   * Handle network errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handleNetworkError(error, context) {
    const { platform, retryCount = 0 } = context;
    
    if (retryCount < 3) {
      // Retry with exponential backoff
      const delay = Math.pow(2, retryCount) * 1000;
      await this.delay(delay);
      
      return {
        success: false,
        error: error.message,
        retryable: true,
        retryAfter: delay,
        fallback: 'retry'
      };
    }
    
    // Fallback to web scraping
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'web_scraping',
      message: 'Network request failed. Trying alternative method...'
    };
  }

  /**
   * Handle parsing errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handleParsingError(error, context) {
    const { platform, data } = context;
    
    // Try alternative parsing methods
    if (data && typeof data === 'string') {
      try {
        const alternativeData = this.tryAlternativeParsing(data, platform);
        if (alternativeData) {
          return {
            success: true,
            data: alternativeData,
            fallback: 'alternative_parsing'
          };
        }
      } catch (altError) {
        console.warn('Alternative parsing failed:', altError);
      }
    }
    
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'manual_input',
      message: 'Failed to parse data. Please try manual input.'
    };
  }

  /**
   * Handle automation errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handleAutomationError(error, context) {
    const { platform, items } = context;
    
    // Fallback to URL generation
    try {
      const cartUrl = await this.generateFallbackCartUrl(items, platform);
      if (cartUrl) {
        return {
          success: true,
          fallback: 'url_generation',
          cartUrl: cartUrl,
          message: 'Automation failed. Generated cart URL instead.'
        };
      }
    } catch (urlError) {
      console.warn('URL generation fallback failed:', urlError);
    }
    
    // Fallback to clipboard copy
    const clipboardData = this.generateClipboardData(items, platform);
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'clipboard_copy',
      clipboardData: clipboardData,
      message: 'Automation failed. Cart data copied to clipboard.'
    };
  }

  /**
   * Handle permission errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handlePermissionError(error, context) {
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'permission_request',
      message: 'Permission required. Please grant necessary permissions.',
      action: 'request_permissions'
    };
  }

  /**
   * Handle platform-specific errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handlePlatformError(error, context) {
    const { platform, alternativePlatforms = [] } = context;
    
    // Try alternative platforms
    if (alternativePlatforms.length > 0) {
      return {
        success: false,
        error: error.message,
        retryable: true,
        fallback: 'alternative_platform',
        alternativePlatforms: alternativePlatforms,
        message: `Platform ${platform} failed. Trying alternatives...`
      };
    }
    
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'manual_input',
      message: 'Platform not supported. Please try manual input.'
    };
  }

  /**
   * Handle unknown errors
   * @param {Error} error 
   * @param {Object} context 
   * @returns {Promise<Object>}
   */
  async handleUnknownError(error, context) {
    return {
      success: false,
      error: error.message,
      retryable: false,
      fallback: 'manual_input',
      message: 'An unexpected error occurred. Please try again or use manual input.'
    };
  }

  /**
   * Try alternative parsing methods
   * @param {string} data 
   * @param {string} platform 
   * @returns {Object|null}
   */
  tryAlternativeParsing(data, platform) {
    try {
      // Try different JSON parsing approaches
      const cleanedData = data.replace(/[^\x20-\x7E]/g, '');
      return JSON.parse(cleanedData);
    } catch (error) {
      try {
        // Try parsing as HTML
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');
        return this.extractDataFromHTML(doc, platform);
      } catch (htmlError) {
        return null;
      }
    }
  }

  /**
   * Extract data from HTML document
   * @param {Document} doc 
   * @param {string} platform 
   * @returns {Object|null}
   */
  extractDataFromHTML(doc, platform) {
    const selectors = this.getPlatformSelectors(platform);
    const products = [];
    
    try {
      const productElements = doc.querySelectorAll(selectors.container);
      
      productElements.forEach(element => {
        const product = {
          id: this.extractText(element, selectors.id),
          title: this.extractText(element, selectors.title),
          price: this.extractText(element, selectors.price),
          imageUrl: this.extractAttribute(element, selectors.image, 'src'),
          productUrl: this.extractAttribute(element, selectors.link, 'href')
        };
        
        if (product.title && product.price) {
          products.push(product);
        }
      });
      
      return { products };
    } catch (error) {
      return null;
    }
  }

  /**
   * Generate fallback cart URL
   * @param {Array} items 
   * @param {string} platform 
   * @returns {Promise<string|null>}
   */
  async generateFallbackCartUrl(items, platform) {
    const platformUrls = {
      'zepto.com': 'https://www.zepto.com/cart',
      'blinkit.com': 'https://www.blinkit.com/cart',
      'bigbasket.com': 'https://www.bigbasket.com/cart'
    };
    
    const baseUrl = platformUrls[platform];
    if (!baseUrl) return null;
    
    // Generate URL with query parameters
    const params = new URLSearchParams();
    items.forEach((item, index) => {
      params.append(`items[${index}][id]`, item.id);
      params.append(`items[${index}][quantity]`, item.quantity);
    });
    
    return `${baseUrl}?${params.toString()}`;
  }

  /**
   * Generate clipboard data
   * @param {Array} items 
   * @param {string} platform 
   * @returns {string}
   */
  generateClipboardData(items, platform) {
    const cartData = {
      platform: platform,
      items: items.map(item => ({
        title: item.title,
        price: item.price,
        quantity: item.quantity,
        url: item.productUrl
      })),
      generatedAt: new Date().toISOString()
    };
    
    return JSON.stringify(cartData, null, 2);
  }

  /**
   * Get platform selectors
   * @param {string} platform 
   * @returns {Object}
   */
  getPlatformSelectors(platform) {
    const selectors = {
      'zepto.com': {
        container: '.product-card',
        id: '.product-id',
        title: '.product-title',
        price: '.price',
        image: '.product-image img',
        link: '.product-link'
      },
      'blinkit.com': {
        container: '.product-item',
        id: '.product-id',
        title: '.product-name',
        price: '.price',
        image: '.product-img img',
        link: '.product-link'
      },
      'bigbasket.com': {
        container: '.product-tile',
        id: '.product-id',
        title: '.product-title',
        price: '.price',
        image: '.product-image img',
        link: '.product-link'
      }
    };
    
    return selectors[platform] || selectors['zepto.com'];
  }

  /**
   * Extract text from element
   * @param {Element} element 
   * @param {string} selector 
   * @returns {string}
   */
  extractText(element, selector) {
    const target = element.querySelector(selector);
    return target ? target.textContent.trim() : '';
  }

  /**
   * Extract attribute from element
   * @param {Element} element 
   * @param {string} selector 
   * @param {string} attribute 
   * @returns {string}
   */
  extractAttribute(element, selector, attribute) {
    const target = element.querySelector(selector);
    return target ? target.getAttribute(attribute) : '';
  }

  /**
   * Create error response
   * @param {Error} error 
   * @param {string} message 
   * @returns {Object}
   */
  createErrorResponse(error, message) {
    return {
      success: false,
      error: error.message,
      message: message,
      retryable: false,
      fallback: 'manual_input'
    };
  }

  /**
   * Delay execution
   * @param {number} ms 
   * @returns {Promise}
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Log error for debugging
   * @param {Error} error 
   * @param {Object} context 
   */
  logError(error, context) {
    const errorLog = {
      timestamp: new Date().toISOString(),
      error: {
        name: error.name,
        message: error.message,
        stack: error.stack
      },
      context: context,
      userAgent: navigator.userAgent,
      url: window.location.href
    };
    
    console.error('Error logged:', errorLog);
    
    // Store error for debugging (in development)
    if (this.isDevelopment()) {
      this.storeErrorLog(errorLog);
    }
  }

  /**
   * Check if in development mode
   * @returns {boolean}
   */
  isDevelopment() {
    return chrome.runtime.getManifest().version_name === 'dev' || 
           window.location.hostname === 'localhost';
  }

  /**
   * Store error log
   * @param {Object} errorLog 
   */
  storeErrorLog(errorLog) {
    try {
      const logs = JSON.parse(localStorage.getItem('cartCompareErrorLogs') || '[]');
      logs.push(errorLog);
      
      // Keep only last 50 errors
      if (logs.length > 50) {
        logs.splice(0, logs.length - 50);
      }
      
      localStorage.setItem('cartCompareErrorLogs', JSON.stringify(logs));
    } catch (error) {
      console.warn('Failed to store error log:', error);
    }
  }

  /**
   * Get error logs
   * @returns {Array}
   */
  getErrorLogs() {
    try {
      return JSON.parse(localStorage.getItem('cartCompareErrorLogs') || '[]');
    } catch (error) {
      return [];
    }
  }

  /**
   * Clear error logs
   */
  clearErrorLogs() {
    localStorage.removeItem('cartCompareErrorLogs');
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ErrorHandler;
} else {
  window.ErrorHandler = ErrorHandler;
}
