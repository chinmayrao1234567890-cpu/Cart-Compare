/**
 * Security and Compliance Module
 * Handles security measures, data protection, and compliance requirements
 */

class SecurityManager {
  constructor() {
    this.allowedDomains = [
      'zepto.com',
      'blinkit.com',
      'bigbasket.com',
      'grofers.com',
      'amazon.in',
      'flipkart.com',
      'jiomart.com'
    ];
    
    this.sensitiveDataFields = [
      'password',
      'creditCard',
      'cvv',
      'ssn',
      'personalId',
      'phoneNumber',
      'email'
    ];
    
    this.initializeSecurity();
  }

  /**
   * Initialize security measures
   */
  initializeSecurity() {
    this.setupCSP();
    this.setupDataSanitization();
    this.setupRateLimiting();
    this.setupPrivacyProtection();
  }

  /**
   * Setup Content Security Policy
   */
  setupCSP() {
    // CSP is handled in manifest.json
    // This method can be used for runtime CSP updates
    const cspDirectives = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "connect-src 'self' https:",
      "frame-src 'none'",
      "object-src 'none'",
      "base-uri 'self'"
    ];
    
    console.log('CSP directives:', cspDirectives.join('; '));
  }

  /**
   * Setup data sanitization
   */
  setupDataSanitization() {
    // Override console methods to prevent sensitive data logging
    const originalLog = console.log;
    const originalError = console.error;
    
    console.log = (...args) => {
      const sanitizedArgs = args.map(arg => this.sanitizeData(arg));
      originalLog.apply(console, sanitizedArgs);
    };
    
    console.error = (...args) => {
      const sanitizedArgs = args.map(arg => this.sanitizeData(arg));
      originalError.apply(console, sanitizedArgs);
    };
  }

  /**
   * Setup rate limiting
   */
  setupRateLimiting() {
    this.rateLimits = {
      apiCalls: { count: 0, resetTime: Date.now() + 60000 }, // 1 minute
      scrapingRequests: { count: 0, resetTime: Date.now() + 300000 }, // 5 minutes
      automationAttempts: { count: 0, resetTime: Date.now() + 600000 } // 10 minutes
    };
  }

  /**
   * Setup privacy protection
   */
  setupPrivacyProtection() {
    // Disable tracking and analytics in sensitive contexts
    this.privacyMode = this.detectPrivacyMode();
    
    if (this.privacyMode) {
      this.disableTracking();
    }
  }

  /**
   * Sanitize sensitive data
   * @param {any} data 
   * @returns {any}
   */
  sanitizeData(data) {
    if (typeof data === 'string') {
      return this.sanitizeString(data);
    }
    
    if (typeof data === 'object' && data !== null) {
      return this.sanitizeObject(data);
    }
    
    return data;
  }

  /**
   * Sanitize string data
   * @param {string} str 
   * @returns {string}
   */
  sanitizeString(str) {
    // Remove potential sensitive patterns
    let sanitized = str;
    
    // Remove credit card numbers
    sanitized = sanitized.replace(/\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/g, '[CARD]');
    
    // Remove phone numbers
    sanitized = sanitized.replace(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g, '[PHONE]');
    
    // Remove email addresses
    sanitized = sanitized.replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, '[EMAIL]');
    
    return sanitized;
  }

  /**
   * Sanitize object data
   * @param {Object} obj 
   * @returns {Object}
   */
  sanitizeObject(obj) {
    const sanitized = {};
    
    for (const [key, value] of Object.entries(obj)) {
      if (this.sensitiveDataFields.some(field => key.toLowerCase().includes(field))) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = this.sanitizeObject(value);
      } else if (typeof value === 'string') {
        sanitized[key] = this.sanitizeString(value);
      } else {
        sanitized[key] = value;
      }
    }
    
    return sanitized;
  }

  /**
   * Validate domain access
   * @param {string} domain 
   * @returns {boolean}
   */
  validateDomain(domain) {
    return this.allowedDomains.some(allowedDomain => 
      domain.includes(allowedDomain)
    );
  }

  /**
   * Check rate limits
   * @param {string} type 
   * @returns {boolean}
   */
  checkRateLimit(type) {
    const limit = this.rateLimits[type];
    if (!limit) return true;
    
    const now = Date.now();
    
    // Reset counter if time window has passed
    if (now > limit.resetTime) {
      limit.count = 0;
      limit.resetTime = now + this.getRateLimitWindow(type);
    }
    
    // Check if limit exceeded
    const maxRequests = this.getMaxRequests(type);
    if (limit.count >= maxRequests) {
      return false;
    }
    
    limit.count++;
    return true;
  }

  /**
   * Get rate limit window for type
   * @param {string} type 
   * @returns {number}
   */
  getRateLimitWindow(type) {
    const windows = {
      apiCalls: 60000, // 1 minute
      scrapingRequests: 300000, // 5 minutes
      automationAttempts: 600000 // 10 minutes
    };
    
    return windows[type] || 60000;
  }

  /**
   * Get max requests for type
   * @param {string} type 
   * @returns {number}
   */
  getMaxRequests(type) {
    const limits = {
      apiCalls: 30, // 30 API calls per minute
      scrapingRequests: 10, // 10 scraping requests per 5 minutes
      automationAttempts: 5 // 5 automation attempts per 10 minutes
    };
    
    return limits[type] || 10;
  }

  /**
   * Detect privacy mode
   * @returns {boolean}
   */
  detectPrivacyMode() {
    // Check for privacy-focused browser features
    const privacyIndicators = [
      navigator.doNotTrack === '1',
      navigator.doNotTrack === 'yes',
      window.chrome && window.chrome.privacy && window.chrome.privacy.websites,
      document.cookie === '' && !document.cookie // No cookies
    ];
    
    return privacyIndicators.some(indicator => indicator);
  }

  /**
   * Disable tracking and analytics
   */
  disableTracking() {
    // Disable any tracking scripts
    const trackingScripts = document.querySelectorAll('script[src*="analytics"], script[src*="tracking"]');
    trackingScripts.forEach(script => script.remove());
    
    // Disable localStorage for tracking
    const originalSetItem = localStorage.setItem;
    localStorage.setItem = function(key, value) {
      if (key.includes('tracking') || key.includes('analytics')) {
        return;
      }
      originalSetItem.call(this, key, value);
    };
  }

  /**
   * Encrypt sensitive data
   * @param {string} data 
   * @returns {string}
   */
  encryptData(data) {
    // Simple encryption for demo purposes
    // In production, use a proper encryption library
    const key = this.getEncryptionKey();
    let encrypted = '';
    
    for (let i = 0; i < data.length; i++) {
      const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
      encrypted += String.fromCharCode(charCode);
    }
    
    return btoa(encrypted);
  }

  /**
   * Decrypt sensitive data
   * @param {string} encryptedData 
   * @returns {string}
   */
  decryptData(encryptedData) {
    try {
      const key = this.getEncryptionKey();
      const data = atob(encryptedData);
      let decrypted = '';
      
      for (let i = 0; i < data.length; i++) {
        const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
        decrypted += String.fromCharCode(charCode);
      }
      
      return decrypted;
    } catch (error) {
      console.error('Decryption failed:', error);
      return '';
    }
  }

  /**
   * Get encryption key
   * @returns {string}
   */
  getEncryptionKey() {
    // Generate a key based on extension ID and user agent
    const extensionId = chrome.runtime.id;
    const userAgent = navigator.userAgent;
    return btoa(extensionId + userAgent).substring(0, 16);
  }

  /**
   * Validate user input
   * @param {any} input 
   * @param {string} type 
   * @returns {boolean}
   */
  validateInput(input, type) {
    switch (type) {
      case 'url':
        return this.validateUrl(input);
      case 'email':
        return this.validateEmail(input);
      case 'number':
        return this.validateNumber(input);
      case 'text':
        return this.validateText(input);
      default:
        return true;
    }
  }

  /**
   * Validate URL
   * @param {string} url 
   * @returns {boolean}
   */
  validateUrl(url) {
    try {
      const urlObj = new URL(url);
      return this.validateDomain(urlObj.hostname);
    } catch (error) {
      return false;
    }
  }

  /**
   * Validate email
   * @param {string} email 
   * @returns {boolean}
   */
  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Validate number
   * @param {any} num 
   * @returns {boolean}
   */
  validateNumber(num) {
    return !isNaN(num) && isFinite(num) && num >= 0;
  }

  /**
   * Validate text
   * @param {string} text 
   * @returns {boolean}
   */
  validateText(text) {
    return typeof text === 'string' && text.length > 0 && text.length < 1000;
  }

  /**
   * Check for XSS vulnerabilities
   * @param {string} input 
   * @returns {boolean}
   */
  checkXSS(input) {
    const xssPatterns = [
      /<script[^>]*>.*?<\/script>/gi,
      /javascript:/gi,
      /on\w+\s*=/gi,
      /<iframe[^>]*>.*?<\/iframe>/gi,
      /<object[^>]*>.*?<\/object>/gi,
      /<embed[^>]*>.*?<\/embed>/gi
    ];
    
    return xssPatterns.some(pattern => pattern.test(input));
  }

  /**
   * Sanitize HTML content
   * @param {string} html 
   * @returns {string}
   */
  sanitizeHTML(html) {
    // Remove potentially dangerous HTML tags and attributes
    const dangerousTags = ['script', 'iframe', 'object', 'embed', 'form'];
    const dangerousAttributes = ['onclick', 'onload', 'onerror', 'onmouseover'];
    
    let sanitized = html;
    
    // Remove dangerous tags
    dangerousTags.forEach(tag => {
      const regex = new RegExp(`<${tag}[^>]*>.*?<\/${tag}>`, 'gi');
      sanitized = sanitized.replace(regex, '');
    });
    
    // Remove dangerous attributes
    dangerousAttributes.forEach(attr => {
      const regex = new RegExp(`\\s${attr}\\s*=\\s*["'][^"']*["']`, 'gi');
      sanitized = sanitized.replace(regex, '');
    });
    
    return sanitized;
  }

  /**
   * Generate secure random string
   * @param {number} length 
   * @returns {string}
   */
  generateSecureRandom(length = 32) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return result;
  }

  /**
   * Create secure hash
   * @param {string} data 
   * @returns {Promise<string>}
   */
  async createSecureHash(data) {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Check compliance requirements
   * @returns {Object}
   */
  checkCompliance() {
    const compliance = {
      gdpr: this.checkGDPRCompliance(),
      ccpa: this.checkCCPACompliance(),
      coppa: this.checkCOPPACompliance(),
      tos: this.checkTOSCompliance()
    };
    
    return compliance;
  }

  /**
   * Check GDPR compliance
   * @returns {boolean}
   */
  checkGDPRCompliance() {
    // Check if user is in EU
    const isEU = this.detectEUUser();
    
    if (isEU) {
      // Ensure data processing consent
      return this.hasDataProcessingConsent();
    }
    
    return true;
  }

  /**
   * Check CCPA compliance
   * @returns {boolean}
   */
  checkCCPACompliance() {
    // Check if user is in California
    const isCalifornia = this.detectCaliforniaUser();
    
    if (isCalifornia) {
      // Ensure privacy rights are respected
      return this.hasPrivacyRightsConsent();
    }
    
    return true;
  }

  /**
   * Check COPPA compliance
   * @returns {boolean}
   */
  checkCOPPACompliance() {
    // Check if user is under 13
    const isUnder13 = this.detectUnder13User();
    
    if (isUnder13) {
      // Ensure parental consent
      return this.hasParentalConsent();
    }
    
    return true;
  }

  /**
   * Check Terms of Service compliance
   * @returns {boolean}
   */
  checkTOSCompliance() {
    // Check if extension respects platform ToS
    const currentDomain = window.location.hostname;
    const platformTOS = this.getPlatformTOS(currentDomain);
    
    return this.respectsPlatformTOS(platformTOS);
  }

  /**
   * Detect EU user
   * @returns {boolean}
   */
  detectEUUser() {
    // Simple detection based on timezone
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const euTimezones = [
      'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Rome',
      'Europe/Madrid', 'Europe/Amsterdam', 'Europe/Brussels', 'Europe/Vienna'
    ];
    
    return euTimezones.includes(timezone);
  }

  /**
   * Detect California user
   * @returns {boolean}
   */
  detectCaliforniaUser() {
    // Simple detection based on timezone
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return timezone === 'America/Los_Angeles';
  }

  /**
   * Detect under-13 user
   * @returns {boolean}
   */
  detectUnder13User() {
    // This would require user input or age verification
    // For now, return false as we don't collect age data
    return false;
  }

  /**
   * Check data processing consent
   * @returns {boolean}
   */
  hasDataProcessingConsent() {
    // Check if user has consented to data processing
    const consent = localStorage.getItem('cartCompareDataConsent');
    return consent === 'true';
  }

  /**
   * Check privacy rights consent
   * @returns {boolean}
   */
  hasPrivacyRightsConsent() {
    // Check if user has consented to privacy rights
    const consent = localStorage.getItem('cartComparePrivacyConsent');
    return consent === 'true';
  }

  /**
   * Check parental consent
   * @returns {boolean}
   */
  hasParentalConsent() {
    // Check if parental consent has been given
    const consent = localStorage.getItem('cartCompareParentalConsent');
    return consent === 'true';
  }

  /**
   * Get platform Terms of Service
   * @param {string} domain 
   * @returns {Object}
   */
  getPlatformTOS(domain) {
    const tosMap = {
      'amazon.in': { scraping: false, automation: false, dataCollection: false },
      'flipkart.com': { scraping: false, automation: false, dataCollection: false },
      'zepto.com': { scraping: true, automation: true, dataCollection: true },
      'blinkit.com': { scraping: true, automation: true, dataCollection: true },
      'bigbasket.com': { scraping: true, automation: true, dataCollection: true }
    };
    
    return tosMap[domain] || { scraping: false, automation: false, dataCollection: false };
  }

  /**
   * Check if extension respects platform ToS
   * @param {Object} tos 
   * @returns {boolean}
   */
  respectsPlatformTOS(tos) {
    // Check if our actions are allowed by platform ToS
    return tos.scraping && tos.automation && tos.dataCollection;
  }

  /**
   * Request user consent
   * @param {string} type 
   * @returns {Promise<boolean>}
   */
  async requestConsent(type) {
    return new Promise((resolve) => {
      const consent = confirm(`CartCompare needs your consent to ${type}. Do you agree?`);
      resolve(consent);
    });
  }

  /**
   * Store consent
   * @param {string} type 
   * @param {boolean} granted 
   */
  storeConsent(type, granted) {
    localStorage.setItem(`cartCompare${type}Consent`, granted.toString());
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SecurityManager;
} else {
  window.SecurityManager = SecurityManager;
}
