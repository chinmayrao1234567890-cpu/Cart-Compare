/**
 * Background Script - Service Worker
 * Handles automation, web scraping, and cross-tab communication
 */

class BackgroundService {
  constructor() {
    this.activeTabs = new Map();
    this.cartPages = new Set();
    this.automationQueue = [];
    
    this.initialize();
  }

  /**
   * Initialize background service
   */
  initialize() {
    this.setupMessageListener();
    this.setupTabListener();
    this.setupWebRequestListener();
  }

  /**
   * Setup message listener for content scripts and popup
   */
  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse);
      return true; // Keep message channel open for async responses
    });
  }

  /**
   * Handle incoming messages
   */
  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.action) {
        case 'cartPageStatus':
          this.handleCartPageStatus(request, sender);
          sendResponse({ success: true });
          break;
          
        case 'cartChanged':
          this.handleCartChanged(request, sender);
          sendResponse({ success: true });
          break;
          
        case 'scrapeSearchResults':
          const scrapeResult = await this.scrapeSearchResults(request.query, request.platform);
          sendResponse(scrapeResult);
          break;
          
        case 'searchProduct':
          const searchResult = await this.searchProductAPI(request.query, request.platform);
          sendResponse(searchResult);
          break;
          
        case 'automateCartBuilding':
          const automationResult = await this.automateCartBuilding(request);
          sendResponse(automationResult);
          break;
          
        case 'getCartData':
          const cartData = await this.getCartData(request.tabId);
          sendResponse(cartData);
          break;
          
        default:
          sendResponse({ error: 'Unknown action' });
      }
    } catch (error) {
      console.error('Background message handling error:', error);
      sendResponse({ error: error.message });
    }
  }

  /**
   * Handle cart page status updates
   */
  handleCartPageStatus(request, sender) {
    if (request.isCartPage) {
      this.cartPages.add(sender.tab.id);
      this.activeTabs.set(sender.tab.id, {
        url: request.url,
        isCartPage: true,
        lastUpdate: Date.now()
      });
    } else {
      this.cartPages.delete(sender.tab.id);
      this.activeTabs.delete(sender.tab.id);
    }
  }

  /**
   * Handle cart changes
   */
  handleCartChanged(request, sender) {
    if (this.activeTabs.has(sender.tab.id)) {
      this.activeTabs.set(sender.tab.id, {
        ...this.activeTabs.get(sender.tab.id),
        cartData: request.cartData,
        lastUpdate: Date.now()
      });
    }
  }

  /**
   * Setup tab listener for cleanup
   */
  setupTabListener() {
    chrome.tabs.onRemoved.addListener((tabId) => {
      this.activeTabs.delete(tabId);
      this.cartPages.delete(tabId);
    });

    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'complete') {
        // Check if tab is still a cart page
        if (this.cartPages.has(tabId)) {
          this.verifyCartPage(tabId, tab.url);
        }
      }
    });
  }

  /**
   * Verify if tab is still a cart page
   */
  async verifyCartPage(tabId, url) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { action: 'checkCartPage' });
      if (!response.isCartPage) {
        this.cartPages.delete(tabId);
        this.activeTabs.delete(tabId);
      }
    } catch (error) {
      // Tab might be closed or content script not ready
      this.cartPages.delete(tabId);
      this.activeTabs.delete(tabId);
    }
  }

  /**
   * Setup web request listener for monitoring
   */
  setupWebRequestListener() {
    // Monitor requests to supported platforms
    const supportedDomains = [
      'zepto.com',
      'blinkit.com',
      'bigbasket.com',
      'grofers.com',
      'amazon.in',
      'flipkart.com'
    ];

    chrome.webRequest.onBeforeRequest.addListener(
      (details) => {
        this.handleWebRequest(details);
      },
      { urls: supportedDomains.map(domain => `https://*.${domain}/*`) },
      ['requestBody']
    );
  }

  /**
   * Handle web requests
   */
  handleWebRequest(details) {
    // Log requests for debugging
    console.log('Web request:', details.url);
    
    // Could be used for tracking cart-related requests
    if (details.url.includes('/cart') || details.url.includes('/add-to-cart')) {
      console.log('Cart-related request detected:', details.url);
    }
  }

  /**
   * Search product using API
   */
  async searchProductAPI(query, platform) {
    try {
      const apiUrl = this.getAPIUrl(platform, query);
      
      const response = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      const products = this.parseAPIResponse(data, platform);
      
      return {
        success: true,
        products: products
      };
    } catch (error) {
      console.error('API search failed:', error);
      return {
        success: false,
        error: error.message,
        products: []
      };
    }
  }

  /**
   * Get API URL for platform
   */
  getAPIUrl(domain, query) {
    const encodedQuery = encodeURIComponent(query);
    
    switch (domain) {
      case 'amazon.com':
        return `https://completion.amazon.com/api/2017/suggestions?q=${encodedQuery}&limit=10`;
      case 'walmart.com':
        return `https://www.walmart.com/typeahead/v2/complete?query=${encodedQuery}&maxItems=10`;
      case 'target.com':
        return `https://redsky.target.com/v3/plp/search/?keyword=${encodedQuery}&count=10`;
      default:
        throw new Error(`Unsupported platform: ${domain}`);
    }
  }

  /**
   * Parse API response
   */
  parseAPIResponse(data, domain) {
    const products = [];
    
    switch (domain) {
      case 'amazon.com':
        if (data.suggestions) {
          data.suggestions.forEach((suggestion, index) => {
            products.push({
              id: `amazon_${index}`,
              title: suggestion.value,
              price: this.extractPriceFromTitle(suggestion.value),
              imageUrl: '',
              url: `https://www.amazon.com/s?k=${encodeURIComponent(suggestion.value)}`,
              brand: this.extractBrandFromTitle(suggestion.value),
              confidence: 0.7
            });
          });
        }
        break;
        
      case 'walmart.com':
        if (data.items) {
          data.items.forEach(item => {
            products.push({
              id: item.usItemId || item.itemId,
              title: item.name,
              price: item.salePrice || item.price,
              imageUrl: item.thumbnailImage,
              url: `https://www.walmart.com/ip/${item.usItemId || item.itemId}`,
              brand: item.brand,
              confidence: 0.8
            });
          });
        }
        break;
        
      case 'target.com':
        if (data.data && data.data.search && data.data.search.products) {
          data.data.search.products.forEach(product => {
            products.push({
              id: product.tcin,
              title: product.item.product_description.title,
              price: product.price.current_retail,
              imageUrl: product.item.enrichment.images.primary_image_url,
              url: `https://www.target.com/p/${product.item.product_description.title.toLowerCase().replace(/\s+/g, '-')}/-/${product.tcin}`,
              brand: product.item.product_description.brand,
              confidence: 0.8
            });
          });
        }
        break;
    }
    
    return products.filter(p => p.price > 0);
  }

  /**
   * Extract price from title text
   */
  extractPriceFromTitle(title) {
    const priceMatch = title.match(/\$(\d+(?:\.\d{2})?)/);
    return priceMatch ? parseFloat(priceMatch[1]) : 0;
  }

  /**
   * Extract brand from title
   */
  extractBrandFromTitle(title) {
    const commonBrands = ['Apple', 'Samsung', 'Nike', 'Adidas', 'Sony', 'LG', 'Dell', 'HP', 'Canon', 'Nikon'];
    for (const brand of commonBrands) {
      if (title.toLowerCase().includes(brand.toLowerCase())) {
        return brand;
      }
    }
    return 'Generic';
  }

  /**
   * Scrape search results from a URL
   */
  async scrapeSearchResults(query, platform) {
    try {
      // Build proper search URL from query and platform
      const searchUrl = this.getSearchUrl(platform, query);
      console.log('Scraping URL:', searchUrl);
      
      // Create a new tab for scraping
      const tab = await this.createScrapingTab(searchUrl);
      
      // Wait for page to load
      await this.waitForTabLoad(tab.id);
      
      // Execute scraping script
      const results = await this.executeScrapingScript(tab.id, platform);
      
      // Close the scraping tab
      chrome.tabs.remove(tab.id);
      
      return {
        success: true,
        products: results
      };
      
    } catch (error) {
      console.error('Scraping failed:', error);
      return {
        success: false,
        error: error.message,
        products: []
      };
    }
  }

  /**
   * Get search URL for platform
   */
  getSearchUrl(domain, query) {
    const encodedQuery = encodeURIComponent(query);
    
    switch (domain) {
      case 'amazon.com':
        return `https://www.amazon.com/s?k=${encodedQuery}`;
      case 'walmart.com':
        return `https://www.walmart.com/search?q=${encodedQuery}`;
      case 'target.com':
        return `https://www.target.com/s?searchTerm=${encodedQuery}`;
      default:
        throw new Error(`Unsupported platform: ${domain}`);
    }
  }

  /**
   * Create a tab for scraping
   */
  async createScrapingTab(url) {
    return new Promise((resolve, reject) => {
      chrome.tabs.create({
        url: url,
        active: false
      }, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(tab);
        }
      });
    });
  }

  /**
   * Wait for tab to load
   */
  async waitForTabLoad(tabId) {
    return new Promise((resolve) => {
      const checkComplete = () => {
        chrome.tabs.get(tabId, (tab) => {
          if (tab.status === 'complete') {
            resolve();
          } else {
            setTimeout(checkComplete, 500);
          }
        });
      };
      checkComplete();
    });
  }

  /**
   * Execute scraping script in tab
   */
  async executeScrapingScript(tabId, platform) {
    const script = this.generateScrapingScript(platform);
    
    return new Promise((resolve, reject) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: this.injectScrapingScript,
        args: [script, platform]
      }, (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (results && results[0]) {
          resolve(results[0].result);
        } else {
          reject(new Error('Scraping script failed'));
        }
      });
    });
  }

  /**
   * Generate scraping script
   */
  generateScrapingScript(platform) {
    return `
      (function() {
        try {
          console.log('Starting scraping for ${platform}');
          const products = [];
          
          // Amazon selectors
          const amazonSelectors = [
            '[data-component-type="s-search-result"]',
            '.s-result-item',
            '[data-asin]'
          ];
          
          // Walmart selectors  
          const walmartSelectors = [
            '[data-testid="item-stack"]',
            '.search-result-gridview-item',
            '[data-item-id]'
          ];
          
          // Target selectors
          const targetSelectors = [
            '[data-test="product-details"]',
            '.styles__StyledCol',
            '[data-testid="product-details"]'
          ];
          
          let productElements = [];
          
          // Try different selectors based on platform
          if (window.location.hostname.includes('amazon')) {
            amazonSelectors.forEach(selector => {
              const elements = document.querySelectorAll(selector);
              if (elements.length > 0) {
                productElements = elements;
                console.log('Using Amazon selector:', selector, elements.length);
              }
            });
          } else if (window.location.hostname.includes('walmart')) {
            walmartSelectors.forEach(selector => {
              const elements = document.querySelectorAll(selector);
              if (elements.length > 0) {
                productElements = elements;
                console.log('Using Walmart selector:', selector, elements.length);
              }
            });
          } else if (window.location.hostname.includes('target')) {
            targetSelectors.forEach(selector => {
              const elements = document.querySelectorAll(selector);
              if (elements.length > 0) {
                productElements = elements;
                console.log('Using Target selector:', selector, elements.length);
              }
            });
          }
          
          console.log('Found ' + productElements.length + ' product elements');
          
          productElements.forEach((element, index) => {
            try {
              // Try multiple title selectors
              const titleSelectors = [
                'h2 a span', 'h3 a span', '.s-size-mini', 
                '[data-testid="product-title"]', '.product-title',
                'h2', 'h3', '.title', '[data-automation-id="product-title"]'
              ];
              
              let title = '';
              for (const selector of titleSelectors) {
                const titleEl = element.querySelector(selector);
                if (titleEl && titleEl.textContent.trim()) {
                  title = titleEl.textContent.trim();
                  break;
                }
              }
              
              // Try multiple price selectors
              const priceSelectors = [
                '.a-price-whole', '.a-offscreen', '.a-price .a-offscreen',
                '[data-testid="current-price"]', '.price-current',
                '.price', '.current-price', '[data-automation-id="product-price"]'
              ];
              
              let price = 0;
              let priceText = '';
              for (const selector of priceSelectors) {
                const priceEl = element.querySelector(selector);
                if (priceEl && priceEl.textContent.trim()) {
                  priceText = priceEl.textContent.trim();
                  const numericPrice = priceText.replace(/[^\\d.,]/g, '');
                  price = parseFloat(numericPrice.replace(',', '')) || 0;
                  if (price > 0) break;
                }
              }
              
              // Try to find product link
              const linkEl = element.querySelector('a[href*="/dp/"], a[href*="/ip/"], a[href*="/p/"]') || 
                           element.querySelector('a');
              const productUrl = linkEl ? linkEl.href : '';
              
              // Try to find image
              const imageEl = element.querySelector('img');
              const imageUrl = imageEl ? (imageEl.src || imageEl.getAttribute('data-src')) : '';
              
              if (title && price > 0) {
                const product = {
                  id: 'scraped_' + index,
                  title: title,
                  price: price,
                  priceText: priceText,
                  imageUrl: imageUrl,
                  url: productUrl,
                  brand: this.extractBrand(title),
                  confidence: 0.8
                };
                
                products.push(product);
                console.log('Product ' + index + ':', product);
              }
            } catch (error) {
              console.error('Error processing product ' + index + ':', error);
            }
          });
          
          console.log('Scraped ' + products.length + ' products successfully');
          return products;
        } catch (error) {
          console.error('Scraping error:', error);
          return [];
        }
      })();
    `;
  }

  /**
   * Extract brand from title
   */
  extractBrand(title) {
    const commonBrands = ['Apple', 'Samsung', 'Nike', 'Adidas', 'Sony', 'LG', 'Dell', 'HP', 'Canon', 'Nikon', 'Microsoft', 'Google', 'Amazon', 'Bose', 'JBL'];
    for (const brand of commonBrands) {
      if (title.toLowerCase().includes(brand.toLowerCase())) {
        return brand;
      }
    }
    return 'Generic';
  }

  /**
   * Inject scraping script (executed in page context)
   */
  injectScrapingScript(script, platform) {
    try {
      const products = [];
      const selectors = this.getPlatformSelectors(platform);
      const productElements = document.querySelectorAll(selectors.container);
      
      productElements.forEach(element => {
        const product = {
          id: this.extractText(element, selectors.id),
          title: this.extractText(element, selectors.title),
          price: this.extractText(element, selectors.price),
          imageUrl: this.extractAttribute(element, selectors.image, 'src'),
          productUrl: this.extractAttribute(element, selectors.link, 'href'),
          brand: this.extractText(element, selectors.brand)
        };
        
        if (product.title && product.price) {
          products.push(product);
        }
      });
      
      return products;
    } catch (error) {
      return { error: error.message };
    }
  }

  /**
   * Get platform-specific selectors
   */
  getPlatformSelectors(platform) {
    const selectors = {
      'amazon.com': {
        container: '[data-component-type="s-search-result"], .s-result-item',
        id: '[data-asin]',
        title: 'h2 a span, .a-size-medium, .a-color-base',
        price: '.a-price-whole, .a-offscreen, .a-price-range',
        image: '.s-image',
        link: 'h2 a',
        brand: '.a-size-base-plus'
      },
      'amazon.in': {
        container: '[data-component-type="s-search-result"], .s-result-item',
        id: '[data-asin]',
        title: 'h2 a span, .a-size-medium, .a-color-base',
        price: '.a-price-whole, .a-offscreen, .a-price-range',
        image: '.s-image',
        link: 'h2 a',
        brand: '.a-size-base-plus'
      },
      'walmart.com': {
        container: '[data-testid="item-stack"], .item-stack',
        id: '[data-testid="item-stack"]',
        title: '[data-testid="product-title"], .product-title',
        price: '.price-current, .price-group',
        image: '.product-image img',
        link: '[data-testid="product-title"]',
        brand: '.product-brand'
      },
      'flipkart.com': {
        container: '._1AtVbE, .IIdQZO ._1AtVbE',
        id: '._1AtVbE',
        title: '._2Kn22P, ._2B_pmu',
        price: '._30jeq3, ._1dJ7ru ._2Kn22P',
        image: '._396cs4',
        link: '._2Kn22P',
        brand: '._2WkVRV'
      }
    };

    return selectors[platform] || selectors['amazon.com'];
  }

  /**
   * Extract text from element
   */
  extractText(element, selector) {
    const target = element.querySelector(selector);
    return target ? target.textContent.trim() : '';
  }

  /**
   * Extract attribute from element
   */
  extractAttribute(element, selector, attribute) {
    const target = element.querySelector(selector);
    return target ? target.getAttribute(attribute) : '';
  }

  /**
   * Automate cart building
   */
  async automateCartBuilding(request) {
    try {
      const { matchedProducts, platform } = request;
      const results = {
        success: true,
        addedItems: [],
        failedItems: [],
        message: ''
      };

      // Create new tab for target platform
      const tab = await this.createPlatformTab(platform);
      
      for (const match of matchedProducts) {
        try {
          await this.addProductToCart(match, platform, tab.id);
          results.addedItems.push(match);
        } catch (error) {
          results.failedItems.push({
            ...match,
            error: error.message
          });
        }
      }

      // Navigate to cart
      await this.navigateToCart(platform, tab.id);
      
      results.message = `Added ${results.addedItems.length} items to cart`;
      
      return results;
      
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Create tab for target platform
   */
  async createPlatformTab(platform) {
    const platformUrls = {
      'zepto.com': 'https://www.zepto.com',
      'blinkit.com': 'https://www.blinkit.com',
      'bigbasket.com': 'https://www.bigbasket.com',
      'grofers.com': 'https://www.grofers.com'
    };

    const url = platformUrls[platform] || 'https://www.zepto.com';
    
    return new Promise((resolve, reject) => {
      chrome.tabs.create({
        url: url,
        active: false
      }, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(tab);
        }
      });
    });
  }

  /**
   * Add product to cart
   */
  async addProductToCart(match, platform, tabId) {
    const product = match.matchedProduct;
    const quantity = match.originalItem.quantity;

    // Navigate to product page
    await this.navigateToProduct(product.productUrl, tabId);
    
    // Wait for page to load
    await this.waitForTabLoad(tabId);

    // Execute add to cart script
    await this.executeAddToCartScript(product, quantity, platform, tabId);
  }

  /**
   * Navigate to product page
   */
  async navigateToProduct(productUrl, tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.update(tabId, {
        url: productUrl,
        active: false
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Execute add to cart script
   */
  async executeAddToCartScript(product, quantity, platform, tabId) {
    const script = this.generateAddToCartScript(platform);
    
    return new Promise((resolve, reject) => {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: this.injectAddToCartScript,
        args: [script, product, quantity, platform]
      }, (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (results && results[0] && results[0].result.success) {
          resolve();
        } else {
          reject(new Error('Failed to add product to cart'));
        }
      });
    });
  }

  /**
   * Generate add to cart script
   */
  generateAddToCartScript(platform) {
    const selectors = this.getAddToCartSelectors(platform);
    
    return `
      (function() {
        try {
          // Set quantity
          const quantityElement = document.querySelector('${selectors.quantity}');
          if (quantityElement) {
            quantityElement.value = ${quantity};
            quantityElement.dispatchEvent(new Event('change'));
          }

          // Click add to cart button
          const addButton = document.querySelector('${selectors.button}');
          if (addButton) {
            addButton.click();
            return { success: true };
          } else {
            return { success: false, error: 'Add to cart button not found' };
          }
        } catch (error) {
          return { success: false, error: error.message };
        }
      })();
    `;
  }

  /**
   * Inject add to cart script (executed in page context)
   */
  injectAddToCartScript(script, product, quantity, platform) {
    try {
      const selectors = this.getAddToCartSelectors(platform);
      
      // Set quantity
      const quantityElement = document.querySelector(selectors.quantity);
      if (quantityElement) {
        quantityElement.value = quantity;
        quantityElement.dispatchEvent(new Event('change'));
      }

      // Click add to cart button
      const addButton = document.querySelector(selectors.button);
      if (addButton) {
        addButton.click();
        return { success: true };
      } else {
        return { success: false, error: 'Add to cart button not found' };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Get add to cart selectors
   */
  getAddToCartSelectors(platform) {
    const selectors = {
      'zepto.com': {
        button: '.add-to-cart-btn, .btn-add-to-cart',
        quantity: '.quantity-selector select'
      },
      'blinkit.com': {
        button: '.add-to-cart, .btn-add',
        quantity: '.qty-selector select'
      },
      'bigbasket.com': {
        button: '.btn-add-to-cart, .add-to-cart',
        quantity: '.qty-selector select'
      }
    };

    return selectors[platform] || selectors['zepto.com'];
  }

  /**
   * Navigate to cart
   */
  async navigateToCart(platform, tabId) {
    const cartUrls = {
      'zepto.com': 'https://www.zepto.com/cart',
      'blinkit.com': 'https://www.blinkit.com/cart',
      'bigbasket.com': 'https://www.bigbasket.com/cart',
      'grofers.com': 'https://www.grofers.com/cart'
    };

    const cartUrl = cartUrls[platform] || 'https://www.zepto.com/cart';
    
    return new Promise((resolve, reject) => {
      chrome.tabs.update(tabId, {
        url: cartUrl,
        active: true
      }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  /**
   * Get cart data for specific tab
   */
  async getCartData(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { action: 'extractCart' });
      return response;
    } catch (error) {
      return { error: error.message };
    }
  }
}

// Initialize background service
const backgroundService = new BackgroundService();
